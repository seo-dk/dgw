from datetime import datetime
import pendulum
from MetaInfoHook import MetaInfoHook
from SFTP import SFTP
from HdfsCopy import main
import re
import time
from airflow import DAG
from airflow.operators.python_operator import PythonOperator
from airflow.operators.dummy import DummyOperator
from airflow.exceptions import AirflowException
from airflow.models import Variable

############################## Config Section ####################################

INTERFACE_ID=replace_dagid
TAGS=replace_tags
DAG_ID=INTERFACE_ID

#serverInfo = mih.GetMetaInfo(INTERFACE_ID)
serverInfo=replace_serverInfo

def getJobSchedule(serverInfo):
    parse_result = serverInfo.JOB_SCHEDULE_EXP.split("+")
    
    if "?" in parse_result:
        index = parse_result.index("?")
        parse_result[index] = "*"

    if serverInfo.INTERFACE_CYCLE == "1h":
        return "{} * * * *".format(parse_result[1])
    elif serverInfo.INTERFACE_CYCLE == "1d":
        return "{} {} * * *".format(parse_result[1],parse_result[2])
    elif serverInfo.INTERFACE_CYCLE == "1w":
        return "{} {} * * {}".format(parse_result[1],parse_result[2],parse_result[5])
    elif serverInfo.INTERFACE_CYCLE == "1M":    
        return "{} {} {} * {}".format(parse_result[1],parse_result[2],parse_result[3],parse_result[5])
        
def getQueueId(serverInfo):
    return Variable.get(serverInfo.IP_NET,default_var="default")

JOB_SCHEDULER=replace_schedule
QUEUE_ID = getQueueId(serverInfo)

############################## Parse Section ####################################


def calculate(ifCycle, cal):
    # +9hour timezone issue
    ctime = time.strftime('%Y%m%d%H',time.localtime(time.time()))
    # a,b,c,d,e,f,g,h,i = time.localtime(time.mktime(time.strptime(ctime,'%Y%m%d%H')) - (60 * 60 * sub) + (32400))
    if ifCycle == "1d":
        a,b,c,d,e,f,g,h,i = time.localtime(time.mktime(time.strptime(ctime,'%Y%m%d%H')) - (60 * 60 * cal * 24))
        return '%04d%02d%02d%02d' % (a,b,c,d)
    else:
        a,b,c,d,e,f,g,h,i = time.localtime(time.mktime(time.strptime(ctime,'%Y%m%d%H')) - (60 * 60 * cal))
        return '%04d%02d%02d%02d' % (a,b,c,d)

def getTimePattern(filePattern):
    r_p1=r'\${yyyyMM.*}'
    #find time pattern
    m_p1 = re.search(r_p1,filePattern)
    timepattern = m_p1.group()
    return timepattern

def getTargetTime(ifCycle,timePattern):
    r_p2=r'[0-9]+'
    resultTime = None
    # find calculate time
    cal = re.search(r_p2,timePattern)
    if cal:
        #get calculate time
        calTime = cal.group()
        targetTime=calculate(ifCycle,int(calTime))
        hhPattern = "HH"
        ddPattern = "dd"
        MMPattern = "MM"
        hhCheck = re.search(hhPattern,timePattern)
        ddCheck = re.search(ddPattern,timePattern)
        MMCheck = re.search(MMPattern,timePattern)
        if hhCheck:
            resultTime = targetTime
        elif ddCheck:
            resultTime = targetTime[:8]
        elif MMCheck:
            resultTime = targetTime[:6]
    return resultTime

def replaceTimePattern():
    fileTargetTime = None

    sourceDirTimePattern = getTimePattern(serverInfo.DATA_SOURCE_DIR)
    sourceDirTimeTarget = getTargetTime(serverInfo.INTERFACE_CYCLE, sourceDirTimePattern)
    
    fileTargetTime = sourceDirTimeTarget

    serverInfo.DATA_SOURCE_DIR = serverInfo.DATA_SOURCE_DIR.replace(sourceDirTimePattern,sourceDirTimeTarget)

    for fileInfo in fileListInfo:
        fileNmTimePattern = getTimePattern(fileInfo.FILE_NM)
        fileNmTimeTarget = getTargetTime(serverInfo.INTERFACE_CYCLE,fileNmTimePattern)

        fileTargetTime = fileNmTimeTarget

        fileInfo.FILE_NM = fileInfo.FILE_NM.replace(fileNmTimePattern,fileNmTimeTarget)

    return fileTargetTime

############################## Main Section ####################################

def StartTransfer():
	mih = MetaInfoHook()
	fileListInfo = mih.GetSourceFolderInfo(INTERFACE_ID)

    fileTargetTime = replaceTimePattern()

    sftp = SFTP(serverInfo,fileListInfo,fileTargetTime)
    
    sftp.startGet()
    
    infoDatPath = sftp.getInfoDatPath()

    if infoDatPath is not None:
        main(infoDatPath,serverInfo.PROTOCOL_NM,serverInfo.INTERFACE_CYCLE,stdout=True)
    else:
        raise AirflowException("No info.dat path")

############################## DAG Setting ####################################

args = {
     'owner' : 'seo',
     'queue' : QUEUE_ID
}
local_tz = pendulum.timezone("Asia/Seoul")

with DAG(
    dag_id = DAG_ID,
    description='This code run sftp code',
    schedule_interval=JOB_SCHEDULER,
    start_date=datetime(2023,4,28,tzinfo=local_tz),
    catchup=False,
    default_args = args,
    tags = TAGS
) as dag:
    StartSchedule = DummyOperator(task_id = 'StartSchedule')
    Start_SFTP = PythonOperator(task_id ='StartSFTP', provide_context = True, python_callable=StartTransfer)
    EndSchedule = DummyOperator(task_id = 'EndSchedule')

    StartSchedule >> Start_SFTP >> EndSchedule
