from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.operators.python import BranchPythonOperator
from airflow.operators.dummy import DummyOperator
from airflow.exceptions import AirflowException
from datetime import datetime
import pendulum

local_tz = pendulum.timezone("Asia/Seoul")

"""
{
         "conf":{
                "interface_id":"IF-T1-TEST-0002",
                "source_path":"/user/samson/hive/samson_biz/user_traffic_base_1h",
                "partitions":{
                        "dt":"20230712",
                        "hh":"00",
			"nw":"4g"
                }
        }
}
"""

DAG_ID = "distcp_test_tpani"
TASK_ID = "Transfer_Distcp"

def Transfer_Distcp(**context):
    from MetaInfoHook import MetaInfoHook
    from CollectHistory import CollectHistory
    from KafkaSend import KafkaSend
    from StatusCode import StatusCode 
    import subprocess
    import socket
    import paramiko

    msgD = {'-1':'argvs error','0':'success','1':'risk path delete','2':'no such dir or connect refused','3':'distcp job fail','4':'data inquality'}
    cmd_template = 'source ~/.bash_profile; /home/hadoop/bin/distcp_from_tpani.sh {0} {1}'
    server='90.90.47.63'
    username='hadoop'
    password='gkdid2023^_'
    port=22

    interface_id = context['dag_run'].conf.get('interface_id')
    src_path = context['dag_run'].conf.get('source_path')
    partitions = context['dag_run'].conf.get('partitions')
    dt=partitions['dt']
    hh=partitions['hh']
    nw=partitions['nw']

    src_path = src_path+"/dt="+dt+"/hh="+hh+"/nw="+nw

    execution_date = context['execution_date']

    try:
        kafka_send = KafkaSend()
        statusCode = StatusCode()
        currentHostName = socket.gethostname()
        #currentHostIp = socket.gethostbyname(socket.gethostname())
        collectHistory = CollectHistory(interface_id, DAG_ID, TASK_ID, currentHostName, "1", execution_date)
        
        # get connect db info
        metaInfoHook = MetaInfoHook()
        metaInfo = metaInfoHook.GetMetaInfo(interface_id)
        folderInfo = metaInfoHook.GetSourceFolderInfo(interface_id)
        fileInfo = folderInfo[0]
        metaInfoHook.dbSessionClose()

        # metaInfo.PROTOCOL_CD, metaInfo.INTERFACE_CYCLE, metaInfo.SYSTEM_CD
        collectHistory.setServerInfo(metaInfo)

        target_dt = dt+hh
        hdfs_dest_path = "/idcube_out/distcp" + fileInfo.HDFS_DIR
        # startCollectH(collect_source_seq,local_path,dest_path,filenm,target_dt,collect_hist_id=None,started_at=None)
        collectHistory.startCollectH(fileInfo.COLLECT_SOURCE_SEQ, src_path, hdfs_dest_path, "", target_dt)
        chd = collectHistory.chdDict[fileInfo.COLLECT_SOURCE_SEQ]

        dest_path = hdfs_dest_path+"/dt="+dt+"/hh="+hh+"/nw="+nw

        # start distcp cmd
        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy)
        ssh.connect(server, port=port, username=username, password=password)
        cmd_to_exec= cmd_template.format(src_path, dest_path)
        sdtin, sdtout, sdterr = ssh.exec_command(cmd_to_exec)
        sdtout.channel.set_combine_stderr(True)

        output = sdtout.readlines()
        msg_code=output[-1].strip()
        org_msg=output[0].strip()

        # print("msgD : ", msgD[str(msg_code)])
        # print(org_msg)
        
        if ssh is not None:
             ssh.close()
             del ssh, sdtin, sdtout, sdterr

        if msg_code is "0":
             print("distcp success: ", msgD[str(msg_code)])
             collectHistory.setStatusCode(chd, statusCode.success)
             kafka_send.send_to_kafka(chd)           
             kafka_send.closeKafka()
        elif msg_code is "4":
             print("distcp success: ", msgD[str(msg_code)])
             collectHistory.setStatusCode(chd, statusCode.distcpError)
             kafka_send.send_to_kafka(chd)           
             kafka_send.closeKafka()
        else :
             print("distcp fail: ", msg_code)
             collectHistory.setStatusCode(chd, statusCode.distcpError)
             kafka_send.send_to_kafka(chd)           
             kafka_send.closeKafka()
             raise AirflowException("Error at distcp msg : " + msgD[str(msg_code)])

    except Exception as e:
        raise AirflowException("Error at distcp : " + str(e)[:1024])

###################################### dag define #############################################

args = {'owner':'seo'}
with DAG(
        dag_id= DAG_ID,
        start_date=datetime(2023, 1, 1, tzinfo=local_tz),
        schedule_interval='@once',
        #schedule_interval='00 * * * *',
        catchup=False,
        tags=['TEST','DISTCP','TPANI'],
        default_args=args
) as dag:

    StartSchedule = DummyOperator(task_id="Start_Schedule")
    TransferDistcp = PythonOperator(task_id=TASK_ID, provide_context=True, python_callable=Transfer_Distcp)
    EndSchedule = DummyOperator(task_id="End_Schedule",trigger_rule='one_success')
    StartSchedule >> TransferDistcp >> EndSchedule
