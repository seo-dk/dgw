from datetime import datetime, timedelta
import pendulum
from airflow import DAG
from airflow.operators.python_operator import PythonOperator
from airflow.operators.dummy import DummyOperator
from airflow.exceptions import AirflowException
from airflow.models import Variable
import logging
from commons.DbConn_Manager import DbConnManager

############################## Config Section ####################################

INTERFACE_ID=replace_dagid
TAGS=replace_tags
DAG_ID=INTERFACE_ID

TASK_ID="StartOracle"

serverInfo=replace_serverInfo

def getQueueId(serverInfo):
    return Variable.get(serverInfo,default_var="default")

JOB_SCHEDULER=replace_schedule
QUEUE_ID = getQueueId(serverInfo)

local_tz = pendulum.timezone("Asia/Seoul")

logger = logging.getLogger(DAG_ID)
logger.setLevel(getattr(logging, Variable.get(DAG_ID, default_var="INFO").upper(), logging.INFO))
############################## Main Section ####################################

class OracleConn(DbConnManager):
    def run(self,execution_date):
        super().start_dbconn(INTERFACE_ID,DAG_ID,TASK_ID,execution_date)

def StartOracle(**context):   
    execution_date = context['execution_date']
    try:
        oracle_conn = OracleConn()
        oracle_conn.run(execution_date)
    except Exception as e:
        raise AirflowException(str(e))


############################## DAG Setting ####################################

args = {
     'owner' : 'mobigen',
     'queue' : QUEUE_ID,
     'email_on_failure' : True,
     'email' : ['hankgood95@mobigen.com','kyunghyunkim22@mobigen.com']
}

args = {
     'owner' : 'mobigen'
}

with DAG(
    dag_id = DAG_ID,
    description='This code run oracle code',
    schedule_interval= JOB_SCHEDULER,
    start_date=datetime(2023,6,13,tzinfo=local_tz),
    catchup=False,
    default_args = args,
    tags = TAGS
) as dag:
    StartSchedule = DummyOperator(task_id = 'StartSchedule')
    OracleSchedule = PythonOperator(task_id =TASK_ID, provide_context = True, python_callable=StartOracle)
    EndSchedule = DummyOperator(task_id = 'EndSchedule')

    StartSchedule >> OracleSchedule >> EndSchedule
