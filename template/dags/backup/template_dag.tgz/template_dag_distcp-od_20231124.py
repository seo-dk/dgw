from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.operators.dummy import DummyOperator
from commons.DistcpOdManager import DistcpOdManager
import pendulum
from datetime import datetime, timedelta
from airflow.models import Variable

def execute_distcp(**context):
    dag_id = context['dag'].dag_id
    task_id = context['task_instance'].task_id
    DistcpOdManager(context, dag_id, task_id).execute()

args = {
    'owner': 'mobigen',
    'queue': Variable.get($IP_NET, default_var = "default"),
    'email_on_failure': True,
    'email_on_retry': False,
    'email': $EMAIL,
    'retries': 4,
    'retry_delay': timedelta(minutes = 5),
    'retry_exponential_backoff': True
}

with DAG(
    dag_id=$DAG_ID,
    description=$DESCRIPTION,
    schedule_interval=None,
    start_date=datetime(2023, 1, 1, tzinfo = pendulum.timezone('Asia/Seoul')),
    catchup=False,
    default_args=args,
    tags=$TAGS,
    dagrun_timeout=timedelta(hours=24)
) as dag:
    StartSchedule = DummyOperator(task_id = 'Start_Schedule')
    TransferDistcp = PythonOperator(task_id = 'Transfer_Distcp', provide_context = True, python_callable = execute_distcp)
    EndSchedule = DummyOperator(task_id = 'End_Schedule', trigger_rule = 'one_success')
    
    StartSchedule >> TransferDistcp >> EndSchedule
