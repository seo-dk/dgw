from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.operators.python import BranchPythonOperator
from airflow.operators.dummy import DummyOperator
from airflow.exceptions import AirflowException
from datetime import datetime
import pendulum

local_tz = pendulum.timezone("Asia/Seoul")

"""
{
        "conf":{
                "interface_id":"IF-TEST-DISTCP-001",
                "source_path":"/user/samson/hive/samson_biz/user_traffic_base_1h",
                "destination_path":"/idcube_out/distcp/samson_biz/user_traffic_base_1h",
                "partitions":{
                        "dt":"20230712",
                        "hh":"00",
			"nw":"4g"
                }
        }
}
"""

def Transfer_Distcp(**context):

    msgD = {'-1':'argvs error','0':'success','1':'risk path delete','2':'no such dir or connect refused','3':'distcp job fail','4':'data inquality'}
    cmd_template = 'source ~/.bash_profile; /home/hadoop/bin/distcp_from_tpani.sh {0} {1}'
    server='90.90.47.63'
    username='hadoop'
    password='gkdid2023^_'
    port=22

    interface_id = context['dag_run'].conf.get('interface_id')
    src_path = context['dag_run'].conf.get('source_path')
    dest_path = context['dag_run'].conf.get('destination_path')
    partitions = context['dag_run'].conf.get('partitions')
    dt=partitions['dt']
    hh=partitions['hh']
    nw=partitions['nw']

    src_path = src_path+"/dt="+dt+"/hh="+hh+"/nw"+nw
    dest_path = dest_path+"/dt="+dt+"/hh="+hh+"/nw"+nw
    cmd_to_exec= cmd_template.format(src_path, desc_pat)

    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy)
    ssh.connect(server, port=port, username=username, password=password)
    sdtin, sdtout, sdterr = ssh.exec_command(cmd_to_exec)
    sdtout.channel.set_combine_stderr(True)

    output = sdtout.readlines()
    msg_code=output[-1].strip()
    org_msg=output[0].strip()

    print(msgD[str(msg_code)])
    print(org_msg)

    if ssh is not None:
        ssh.close()
        del ssh, sdtin, sdtout, sdterr

###################################### dag define #############################################

args = {'owner':'seo'}
with DAG(
        dag_id="distcp_test",
        start_date=datetime(2023, 1, 1, tzinfo=local_tz),
        schedule_interval='@once',
        #schedule_interval='00 * * * *',
        catchup=False,
        tags=['TEST','DISTCP'],
        default_args=args
) as dag:

    StartSchedule = DummyOperator(task_id="Start_Schedule")
    TransferDistcp = PythonOperator(task_id="Transfer_Distcp", provide_context=True, python_callable=Transfer_Distcp)
    EndSchedule = DummyOperator(task_id="End_Schedule",trigger_rule='one_success')
    StartSchedule >> TransferDistcp >> EndSchedule
