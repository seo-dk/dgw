from datetime import datetime, timedelta
import pendulum
from airflow import DAG
from airflow.operators.python_operator import PythonOperator
from airflow.operators.dummy import DummyOperator
from airflow.exceptions import AirflowException
from airflow.models import Variable
import logging

############################## Config Section ####################################

logger = logging.getLogger(__name__)
logger.setLevel(getattr(logging, Variable.get(__name__, default_var="INFO").upper(), logging.INFO))

INTERFACE_ID=replace_dagid
TAGS=replace_tags
DAG_ID=INTERFACE_ID

TASK_ID="StartOracle"

serverInfo=replace_serverInfo

def getQueueId(serverInfo):
    return Variable.get(serverInfo,default_var="default")

JOB_SCHEDULER=replace_schedule
QUEUE_ID = getQueueId(serverInfo)

local_tz = pendulum.timezone("Asia/Seoul")

############################## Main Section ####################################


def StartOracle(**context):
    from MetaInfoHook import MetaInfoHook
    from OracleHook import OracleHook
    from WriteOracleResult import WriteOracleResult
    from HdfsCopy import HdfsCopy
    from Parse import Parse
    from CollectHistory import CollectHistory
    from KafkaSend import KafkaSend
    from SetPath import SetPath
    from DbConnThread import DbConnThread
    import concurrent.futures
    import socket
    from Infodat_IO import InfoDat_IO

    execution_date = context['execution_date']

    try:
        setPath = SetPath()
        parse = Parse()

        metaInfoHook = MetaInfoHook()
        meta_info = metaInfoHook.GetMetaInfo(INTERFACE_ID)
        dataClassInfo = metaInfoHook.DbJsonerverInfo(meta_info.PROTOCOL_DETAILS_JSON)
        fileListInfo = metaInfoHook.GetSourceFolderInfo(INTERFACE_ID)   
        statusCodeInfo = metaInfoHook.GetStatusCode()   
        metaInfoHook.dbSessionClose()

        currentHostName = socket.gethostname()
        collectHistory = CollectHistory(INTERFACE_ID,DAG_ID,TASK_ID,currentHostName,"1",execution_date, statusCodeInfo)
        collectHistory.setServerInfo(meta_info)

        kafka_send = KafkaSend(statusCodeInfo)

        oracleHook = OracleHook(kafka_send, collectHistory, dataClassInfo)
        oracleHook.setDns()
        oracleHook.connectOracle()

        infodat_IO = InfoDat_IO()
        writeOracleResult = WriteOracleResult(kafka_send, collectHistory, setPath, infodat_IO)

        local_info_file_path = setPath.setOracleLocalInfoFilePath(dataClassInfo, INTERFACE_ID)
        dbconnThread = DbConnThread(oracleHook, writeOracleResult, local_info_file_path)

        for file_info in fileListInfo:
            # target_time = datetime.now() - timedelta(minutes=5) 
            current_time = datetime.now()             
            current_time = current_time.strftime('%Y%m%d%H%M')

            # get count sql result
            result_dic = parse.getSqlParams(file_info.DB_QUERY_INFO.count_params, current_time)
            count_params = parse.replaceSqlParamsResult(file_info.DB_QUERY_INFO.count_query, result_dic['param_result'])
            record_count = oracleHook.executeCountSql(file_info.DB_QUERY_INFO.count_query, count_params)

            # get data sql's params
            result_dic = parse.getSqlParams(file_info.DB_QUERY_INFO.data_params, current_time)
            sql_params = parse.replaceSqlParamsResult(file_info.DB_QUERY_INFO.data_query, result_dic['param_result'])
            num_rows = int(file_info.DB_QUERY_INFO.num_rows)

            row_num_list = parse.getRowNumList(record_count, num_rows)      
            query_list = parse.getDataQueryList(row_num_list, num_rows, file_info.DB_QUERY_INFO.data_query)
            
            target_time = parse.getOracleTragetTime(result_dic['param_result'])

            # /data/airflow/C-TMS-DBCONN-MI-0002/db=o_tms/TMS_SUBWAY_AREA_QUALITY/TMS_SUBWAY_AREA_QUALITY_202307261420_
            local_file_path = setPath.setOracleLocalFilePath(dataClassInfo, INTERFACE_ID, file_info, target_time)

            # multi thread
            worker_min = len(query_list)
            worker = min(10, worker_min)
            future_list = []
            with concurrent.futures.ThreadPoolExecutor(max_workers = worker) as executor:
                # execute query and write to local
                for query in query_list:
                    future = executor.submit(dbconnThread.run, query, sql_params, local_file_path, meta_info, file_info, current_time, target_time) 
                    future_list.append(future)
               
                # concurrent.futures.wait(future_list, timeout=90, return_when=concurrent.futures.ALL_COMPLETED)
                completed_futures, failed_futures = concurrent.futures.wait(future_list, timeout=90, return_when=concurrent.futures.ALL_COMPLETED)

                if failed_futures:
                    # for failed_future in failed_futures:
                    #     ulid = failed_future.result()
                    #     chd = collectHistory.chdDict[ulid]
                    #     chd.err_msg="Error DBCONN chd[{}]".format(ulid)
                    #     collectHistory.setStatusCode(chd, "error")
                    kafka_send.sendErrorKafka(collectHistory, 10, False, "Some Thread failed")
                    raise AirflowException("Thread failed")
                else:
                    logger.info('Thread completed')

        if local_info_file_path is not None:
            hdfs_copy = HdfsCopy(kafka_send, collectHistory, "")
            hdfs_copy.checkDir(local_info_file_path)
            hdfs_copy.main(local_info_file_path, stdout=True, retry=False)
        else:
            raise AirflowException("No info.dat path")
            
        oracleHook.closeConnection()       
        kafka_send.closeKafka()
        
    except Exception as e:
        kafka_send.closeKafka()
        raise AirflowException(str(e))    


############################## DAG Setting ####################################

args = {
     'owner' : 'seo',
     'queue' : QUEUE_ID
}

with DAG(
    dag_id = DAG_ID,
    description='This code run oracle code',
    schedule_interval= JOB_SCHEDULER,
    start_date=datetime(2023,6,13,tzinfo=local_tz),
    catchup=False,
    default_args = args,
    tags = TAGS
) as dag:
    StartSchedule = DummyOperator(task_id = 'StartSchedule')
    OracleSchedule = PythonOperator(task_id =TASK_ID, provide_context = True, python_callable=StartOracle)
    EndSchedule = DummyOperator(task_id = 'EndSchedule')

    StartSchedule >> OracleSchedule >> EndSchedule
