from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.operators.python import BranchPythonOperator
from airflow.operators.dummy import DummyOperator
from airflow.exceptions import AirflowException
from datetime import datetime, timedelta
import pendulum
import logging
from airflow.models import Variable
from commons.OD_Collect_Manager import OD_Collect_Manager

local_tz = pendulum.timezone("Asia/Seoul")

logger = logging.getLogger(__name__)

# DAG_ID = "TEST_OD_DAG"
# INTERFACE_ID = "IF-T2-3401-01"
# TAGS = ["restAPI", "FTP", "ON_DEMAND"]
# TASK_ID = "StartTransfer"

TASK_ID = "StartTransfer"
INTERFACE_ID=replace_dagid
TAGS=replace_tags
DAG_ID=INTERFACE_ID

JOB_SCHEDULER = "@once"

serverInfo = "ip_net_90"
logger.setLevel(getattr(logging, Variable.get(DAG_ID, default_var="INFO").upper(), logging.INFO))


def getQueueId(serverInfo):
    from airflow.models import Variable

    return Variable.get(serverInfo, default_var="default")


QUEUE_ID = getQueueId(serverInfo)

local_tz = pendulum.timezone("Asia/Seoul")

def od_Run(**context):
    od_start = OD_Collect_Manager()
    od_start.execute(context, DAG_ID, TASK_ID)

args = {
    'owner': 'mobigen',
    'email_on_failure': True,
    'email': ['hankgood95@mobigen.com', 'kyunghyunkim22@mobigen.com'],
    'queue': QUEUE_ID,
    'retries': 3,
    'retry_delay': timedelta(minutes=1)
}

with DAG(
        dag_id=DAG_ID,
        description='This code run sftp code',
        schedule_interval=JOB_SCHEDULER,
        # schedule_interval = timedelta(seconds=10),
        start_date=datetime(2023, 4, 28, tzinfo=local_tz),
        catchup=False,
        default_args=args,
        tags=TAGS
) as dag:
    StartSchedule = DummyOperator(task_id='StartSchedule')
    Start_SFTP = PythonOperator(task_id=TASK_ID, provide_context=True, python_callable=od_Run)
    EndSchedule = DummyOperator(task_id='EndSchedule')

    StartSchedule >> Start_SFTP >> EndSchedule
