from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.operators.python import BranchPythonOperator
from airflow.operators.dummy import DummyOperator
from airflow.exceptions import AirflowException
from commons.Distcp_OD_Manager import DistcpTransfer
from datetime import datetime
import pendulum
from datetime import datetime, timedelta
from airflow.models import Variable

# INTERFACE_ID = "C-TPANI-DISTCP-OD-0001"
# TAGS = ["C-TPANI-DISTCP-OD-0001", "FTP", "HDFS", "DAG_TEST"]
# DAG_ID = "TEST_DISTCP"
# TASK_ID = "Transfer_Distcp_Tpani"

TASK_ID = "Transfer_Distcp_Tpani"
INTERFACE_ID=replace_dagid
TAGS=replace_tags
DAG_ID=INTERFACE_ID

serverInfo = "ip_net_90"


def getQueueId(serverInfo):
    return Variable.get(serverInfo, default_var="default")


JOB_SCHEDULER = "@once"
QUEUE_ID = getQueueId(serverInfo)


def execute_distcp(**kwargs):
    DistcpTransfer(kwargs, DAG_ID, TASK_ID).execute()


############################## DAG Setting ####################################

args = {
    'owner': 'mobigen',
    'email_on_failure': True,
    'email': ['hankgood95@mobigen.com', 'kyunghyunkim22@mobigen.com'],
    'queue': QUEUE_ID,
    'retries': 3,
    'retry_delay': timedelta(minutes=1)
}

# args = {
#     'owner': 'mobigen',
#     'queue': QUEUE_ID
# }

with DAG(
        dag_id=DAG_ID,
        start_date=datetime(2023, 1, 1, tzinfo=pendulum.timezone("Asia/Seoul")),
        schedule_interval='@once',
        # schedule_interval='00 * * * *',
        catchup=False,
        tags=['DISTCP', 'ON_DEMAND', 'restAPI', 'TPANI'],
        default_args=args
) as dag:
    StartSchedule = DummyOperator(task_id="Start_Schedule")
    TransferDistcp = PythonOperator(task_id=TASK_ID, provide_context=True, python_callable=execute_distcp)
    EndSchedule = DummyOperator(task_id="End_Schedule", trigger_rule='one_success')
    StartSchedule >> TransferDistcp >> EndSchedule
