from datetime import datetime
import pendulum
from File_Collect_Manager import FileCollectManager
from airflow import DAG
from airflow.operators.python_operator import PythonOperator
from airflow.operators.dummy import DummyOperator
from airflow.exceptions import AirflowException
from airflow.models import Variable
import logging

############################## Config Section ####################################

logger = logging.getLogger(__name__)
logger.setLevel(getattr(logging, Variable.get(__name__, default_var="INFO").upper(), logging.INFO))

INTERFACE_ID=replace_dagid
TAGS=replace_tags
DAG_ID=INTERFACE_ID

# DAG_ID="DAG_TEST_FTP"
# INTERFACE_ID="C-IAM-FTP-HH-0001"
# TAGS=["C-IAM-FTP-HH-0001","SFTP","HDFS","DAG_TEST"]
TASK_ID = "StartTransfer"

serverInfo=replace_serverInfo
# serverInfo="ip_net_90"
        
def getQueueId(serverInfo):
    return Variable.get(serverInfo,default_var="default")

JOB_SCHEDULER=replace_schedule
# JOB_SCHEDULER="@once"
# JOB_SCHEDULER="30 15 * * *"
# JOB_SCHEDULER="*/1 * * * *"
QUEUE_ID = getQueueId(serverInfo)

local_tz = pendulum.timezone("Asia/Seoul")

############################## Main Section ####################################

class CollectStart(FileCollectManager):
    def collect_start(self,execution_date):
        super().start_collect(INTERFACE_ID,DAG_ID,TASK_ID,execution_date)

def StartTransfer(**context):
    execution_date = context['execution_date']
    try:
        collect_start = CollectStart()
        collect_start.collect_start(execution_date)
    except Exception as e:
        raise AirflowException(str(e))

############################## DAG Setting ####################################

args = {
     'owner' : 'seo',
     'queue' : QUEUE_ID
}

with DAG(
    dag_id = DAG_ID,
    description='This code run sftp code',
    schedule_interval=JOB_SCHEDULER,
    # schedule_interval = timedelta(seconds=10),
    start_date=datetime(2023,4,28,tzinfo=local_tz),
    catchup=False,
    default_args = args,
    tags = TAGS
) as dag:
    StartSchedule = DummyOperator(task_id = 'StartSchedule')
    Start_SFTP = PythonOperator(task_id =TASK_ID, provide_context = True, python_callable=StartTransfer)
    EndSchedule = DummyOperator(task_id = 'EndSchedule')

    StartSchedule >> Start_SFTP >> EndSchedule
