from datetime import datetime
import pendulum
from airflow import DAG
from airflow.operators.python_operator import PythonOperator
from airflow.operators.dummy import DummyOperator
from airflow.exceptions import AirflowException

############################## Config Section ####################################

INTERFACE_ID=replace_dagid
TAGS=replace_tags
DAG_ID=INTERFACE_ID
TASK_ID = "StartTransfer"

# INTERFACE_ID="IF-T2-7022-01"
# TAGS=["IF-T2-7022-01","SFTP","HDFS","DAG_TEST"]
# TASK_ID = "StartTransfer"

# serverInfo=replace_serverInfo
serverInfo="ip_net_90"
        
def getQueueId(serverInfo):
    from airflow.models import Variable

    return Variable.get(serverInfo,default_var="default")

JOB_SCHEDULER=replace_schedule
# JOB_SCHEDULER="@once"
# JOB_SCHEDULER="*/1 * * * *"
QUEUE_ID = getQueueId(serverInfo)

############################## Main Section ####################################

def StartTransfer(**context):
    from MetaInfoHook import MetaInfoHook
    from SFTP import SFTP
    from HdfsCopy import main
    from Parse import Parse
    from CollectHistory import CollectHistory
    from KafkaSend import KafkaSend
    from StatusCode import success
    import socket
    
    DAG_RUN_ID = context['run_id']

    try:

        kafka_send = KafkaSend()
        currentHostName = socket.gethostname()
        collectHistory = CollectHistory(INTERFACE_ID,DAG_RUN_ID,TASK_ID,currentHostName,"1")

        mih = MetaInfoHook(collectHistory)
        
        interfaceInfo = mih.GetMetaInfo(INTERFACE_ID)
        fileListInfo = mih.GetSourceFolderInfo(INTERFACE_ID)

        mih.dbSessionClose()

        collectHistory = mih.getCollectHistory()

        collectHistory.setServerInfo(interfaceInfo)

        parse = Parse()

        fileTargetTime = parse.replaceTimePattern(fileListInfo,interfaceInfo)

        sftp = SFTP(interfaceInfo,fileListInfo,fileTargetTime,kafka_send)
        
        sftp.startSFTPGet(collectHistory)

        infoDatPath = sftp.getInfoDatPath()
        # infoDatPath = "/data2/20230621/12/IF-T2-7022-01/info.dat"
        if infoDatPath is not None:
            main(infoDatPath,collectHistory,kafka_send,stdout=True)
        else:
            raise AirflowException("No info.dat path")
        
        kafka_send.closeKafka()
    except AirflowException as e:
        raise AirflowException(str(e))
    except Exception as e:
        e.collect_history_data.err_msg = str(e)[:1024]
        kafka_send.send_to_kafka(e.collect_history_data)
        kafka_send.closeKafka()
        raise AirflowException(str(e))

############################## DAG Setting ####################################

args = {
     'owner' : 'seo',
     'queue' : QUEUE_ID
}

local_tz = pendulum.timezone("Asia/Seoul")

with DAG(
    dag_id = DAG_ID,
    description='This code run sftp code',
    schedule_interval=JOB_SCHEDULER,
    start_date=datetime(2023,4,28,tzinfo=local_tz),
    catchup=False,
    default_args = args,
    tags = TAGS
) as dag:
    StartSchedule = DummyOperator(task_id = 'StartSchedule')
    Start_SFTP = PythonOperator(task_id =TASK_ID, provide_context = True, python_callable=StartTransfer)
    EndSchedule = DummyOperator(task_id = 'EndSchedule')

    StartSchedule >> Start_SFTP >> EndSchedule
