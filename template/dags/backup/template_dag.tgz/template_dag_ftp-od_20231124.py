from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.operators.dummy import DummyOperator
from datetime import datetime, timedelta
import pendulum
import logging
from airflow.models import Variable
from commons.OdCollectManager import OdCollectManager

def run(**context):
    dag_id = context['dag'].dag_id
    task_id = context['task_instance'].task_id
    manager = OdCollectManager()
    manager.execute(context, dag_id, task_id)

args = {
    'owner': 'mobigen',
    'email_on_failure': True,
    'email_on_retry': False,
    'email': $EMAIL,
    'queue': Variable.get($IP_NET, default_var="default"),
    'retries': 4,
    'retry_delay': timedelta(minutes=5),
    'retry_exponential_backoff': True
}

with DAG(
    dag_id=$DAG_ID,
    description=$DESCRIPTION,
    schedule_interval=None,
    start_date=datetime(2023, 4, 28, tzinfo = pendulum.timezone('Asia/Seoul')),
    catchup=False,
    default_args=args,
    tags=$TAGS,
    dagrun_timeout=timedelta(hours=24)
) as dag:
    StartSchedule = DummyOperator(task_id = 'StartSchedule')
    Start_SFTP = PythonOperator(task_id = 'StartTransfer', provide_context = True, python_callable = run)
    EndSchedule = DummyOperator(task_id = 'EndSchedule')

    StartSchedule >> Start_SFTP >> EndSchedule
