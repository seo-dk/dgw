from datetime import datetime, timedelta
import pendulum
import pytz
from croniter import croniter
from airflow import DAG
from airflow.operators.python_operator import PythonOperator
from airflow.operators.dummy import DummyOperator
from airflow.exceptions import AirflowException
import logging
from commons.File_Collect_Manager import FileCollectManager


INTERFACE_ID=replace_dagid
TAGS=replace_tags
DAG_ID=INTERFACE_ID

TASK_ID = "StartTransfer"

serverInfo=replace_serverInfo
        
def getQueueId(serverInfo):
    from airflow.models import Variable

    return Variable.get(serverInfo,default_var="default")

JOB_SCHEDULER=replace_schedule
QUEUE_ID = getQueueId(serverInfo)

local_tz = pendulum.timezone("Asia/Seoul")

############################## Main Section ####################################

class CollectStart(FileCollectManager):
    def collect_start(self,execution_date):
        cron = croniter(JOB_SCHEDULER, execution_date.replace(tzinfo=pytz.utc).astimezone(pytz.timezone('Asia/Seoul')))
        super().__init__()
        super().start_collect(INTERFACE_ID,DAG_ID,TASK_ID,cron.get_next(datetime))

def StartTransfer(**context):
    
    execution_date = context['execution_date']
    try:
        collect_start = CollectStart()
        collect_start.collect_start(execution_date)
    except Exception as e:
        raise AirflowException(str(e))


args = {
     'owner' : 'mobigen',
     'queue' : QUEUE_ID,
     'email_on_failure' : True,
     'email' : ['hankgood95@mobigen.com','kyunghyunkim22@mobigen.com'],
     'retries' : 3,
     'retry_delay' : timedelta(minutes=1)
}

with DAG(
    dag_id = DAG_ID,
    description='This code run sftp code',
    schedule_interval=JOB_SCHEDULER,
    start_date=datetime(2023,4,28,tzinfo=local_tz),
    catchup=False,
    default_args = args,
    tags = TAGS
) as dag:
    StartSchedule = DummyOperator(task_id = 'StartSchedule')
    Start_SFTP = PythonOperator(task_id =TASK_ID, provide_context = True, python_callable=StartTransfer)
    EndSchedule = DummyOperator(task_id = 'EndSchedule')

    StartSchedule >> Start_SFTP >> EndSchedule
