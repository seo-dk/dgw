from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.operators.python import BranchPythonOperator
from airflow.operators.dummy import DummyOperator
from airflow.exceptions import AirflowException
from datetime import datetime
import pendulum
import logging
from airflow.models import Variable

############################## Config Section ####################################
DAG_ID = "DISTCP_TPANI_DAG"
TASK_ID = "Transfer_Distcp_Tpani"

server='90.90.47.63'
username='hadoop'
password='gkdid2023^_'
port=22
cmd_template = 'source ~/.bash_profile; /home/hadoop/bin/distcp_from_tpani.sh {0} {1}'
# cmd_template2 = 'source ~/.bash_profile; /home/hadoop/bin/distcp_from_datalake.sh {0} {1}'

local_tz = pendulum.timezone("Asia/Seoul")
############################## Main Section ####################################

logger = logging.getLogger(DAG_ID)
logger.setLevel(getattr(logging, Variable.get(DAG_ID, default_var="INFO").upper(), logging.INFO))

    

def Transfer_Distcp_Tpani(**context):
    from MetaInfoHook import MetaInfoHook
    from CollectHistory import CollectHistory
    from KafkaSend import KafkaSend
    import socket
    import paramiko

    msgD = {'-1':'argvs error','0':'success','1':'risk path delete','2':'no such dir or connect refused','3':'distcp job fail','4':'data inquality'}

    interface_id = context['dag_run'].conf.get('interface_id')
    src_path = context['dag_run'].conf.get('source_path')
    dest_path = context['dag_run'].conf.get('destination_path')
    partitions = context['dag_run'].conf.get('partitions')
    
    #     src_path = src_path+"/dt="+dt+"/hh="+hh
#     target_dt = dt+hh
#     hdfs_dest_path = dest_path + partition

    # get period for kafka message
    period = ""   
    if 'period=1h' in src_path:
          period = "0 * * * *"
    elif 'period=1d' in src_path:
          period = "0 0 * * *"
    elif 'period=1w' in src_path:
          period = "0 0 * * 4"
    elif 'period=1m' in src_path:
          period = "0 0 1-7 * 5"

    partitions_list = []
    partitions_str = ""
    target_dt = ""

    for key, value in partitions.items():      
        dict = {}
        dict[key] = value     
        partitions_list.append(dict) 
        
        if key is not "" and value is not "":
                logger.debug("Key: %s , Value: %s", key, value)
                if key == 'dt' or key == 'hh':
                        target_dt += str(value)
                format = "/{}={}".format(key, value)
                partitions_str += format
  
    src_path += partitions_str    
    hdfs_dest_path = dest_path + partitions_str
    
    logger.info("target_dt : %s", target_dt)
    logger.info("src_path : %s", src_path)
    logger.info("hdfs_dest_path : %s", hdfs_dest_path)

    execution_date = context['execution_date']
    try:
        # get connect db info
        metaInfoHook = MetaInfoHook()
        metaInfo = metaInfoHook.GetMetaInfo(interface_id)
        folderInfo = metaInfoHook.GetSourceFolderInfo(interface_id)
        statusCodeInfo = metaInfoHook.GetStatusCode()   
        metaInfoHook.dbSessionClose()

        currentHostName = socket.gethostname()
        collectHistory = CollectHistory(interface_id, DAG_ID, TASK_ID, currentHostName, "1", execution_date, statusCodeInfo)
        collectHistory.setServerInfo(metaInfo)
        collectHistory.serverInfo.period = period
        
        kafka_send = KafkaSend(statusCodeInfo)
        
        for file_info in folderInfo:
                chd_ulid = collectHistory.startCollectH(collect_source_seq=file_info.COLLECT_SOURCE_SEQ, 
                                             local_path="",
                                             dest_path=hdfs_dest_path, 
                                             filenm="",
                                             target_dt=target_dt, 
                                             partitions=partitions_list)

                chd = collectHistory.chdDict[chd_ulid]
                collectHistory.setStatusCode(chd,0)
                
                # start distcp cmd
                ssh = paramiko.SSHClient()
                ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy)
                ssh.connect(server, port=port, username=username, password=password)
                cmd_to_exec= cmd_template.format(src_path, hdfs_dest_path)
                sdtin, sdtout, sdterr = ssh.exec_command(cmd_to_exec)
                sdtout.channel.set_combine_stderr(True)

                output = sdtout.readlines()
                msg_code=output[-1].strip()
                org_msg=output[0].strip()
                
                current_time = datetime.now().isoformat()
                chd.ended_at = current_time

                if ssh is not None:
                        ssh.close()
                        del ssh, sdtin, sdtout, sdterr

                if msg_code is "0":
                        logger.info("distcp success: %s", msgD[str(msg_code)])
                        collectHistory.setStatusCode(chd, 4)
                        kafka_send.send_to_kafka(chd)           
                        kafka_send.closeKafka()
                elif msg_code is "4":
                        logger.warn("data inquality")
                        logger.info("distcp success: %s", msgD[str(msg_code)])
                        collectHistory.setStatusCode(chd, 5)
                        kafka_send.send_to_kafka(chd)           
                        kafka_send.closeKafka()
                else :
                        logger.error("distcp fail: %s", msgD[str(msg_code)])
                        kafka_send.sendErrorKafka(collectHistory, 9, False, "distcp failed")        
                        kafka_send.closeKafka()
                        raise AirflowException("Error at distcp")
        
    except Exception as e:
        kafka_send.closeKafka()
        logger.exception(f"Transfer_Distcp error: {e}") 
        raise AirflowException("Error at distcp : " + str(e)[:1024])


###################################### dag define #############################################

args = {'owner':'seo'}
with DAG(
        dag_id= DAG_ID,
        start_date=datetime(2023, 1, 1, tzinfo=local_tz),
        schedule_interval='@once',
        #schedule_interval='00 * * * *',
        catchup=False,
        tags=['DISTCP', 'ON_DEMAND', 'restAPI', 'TPANI'],
        default_args=args
) as dag:

    StartSchedule = DummyOperator(task_id="Start_Schedule")
    TransferDistcp = PythonOperator(task_id=TASK_ID, provide_context=True, python_callable=Transfer_Distcp_Tpani)
    EndSchedule = DummyOperator(task_id="End_Schedule",trigger_rule='one_success')
    StartSchedule >> TransferDistcp >> EndSchedule
