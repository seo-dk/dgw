from datetime import datetime, timedelta
import pendulum
from airflow import DAG
from airflow.operators.python_operator import PythonOperator
from airflow.operators.dummy import DummyOperator
from airflow.models import Variable
import logging
from commons.DbConnManager import DbConnManager

def StartOracle(**context):
    DbConnManager(context).start()

args = {
    'owner': 'mobigen',
    'queue': Variable.get($IP_NET, default_var = "default"),
    'email_on_failure': True,
    'email_on_retry': False,
    'email': $EMAIL,
    'retries': 4,
    'retry_delay': timedelta(minutes = 5),
    'retry_exponential_backoff': True
}

with DAG(
    dag_id=$DAG_ID,
    description=$DESCRIPTION,
    schedule_interval=$JOB_SCHEDULE_EXP,
    start_date=datetime(2023, 6, 13, tzinfo=pendulum.timezone('Asia/Seoul')),
    catchup=False,
    default_args=args,
    tags=$TAGS,
    dagrun_timeout=timedelta(hours=24)
) as dag:
    StartSchedule = DummyOperator(task_id = 'StartSchedule')
    OracleSchedule = PythonOperator(task_id = 'StartOracle', provide_context = True, python_callable = StartOracle)
    EndSchedule = DummyOperator(task_id = 'EndSchedule')

    StartSchedule >> OracleSchedule >> EndSchedule
