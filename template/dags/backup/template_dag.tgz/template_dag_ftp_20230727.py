from datetime import datetime, timedelta
import pendulum
from airflow import DAG
from airflow.operators.python_operator import PythonOperator
from airflow.operators.dummy import DummyOperator
from airflow.exceptions import AirflowException

############################## Config Section ####################################

INTERFACE_ID=replace_dagid
TAGS=replace_tags
DAG_ID=INTERFACE_ID

# DAG_ID="DAG_TEST_FTP"
# INTERFACE_ID="C-ITT-FTP-DD-0001"
# TAGS=["C-ITT-FTP-DD-0001","SFTP","HDFS","DAG_TEST"]
TASK_ID = "StartTransfer"

serverInfo=replace_serverInfo
# serverInfo="ip_net_90"
        
def getQueueId(serverInfo):
    from airflow.models import Variable

    return Variable.get(serverInfo,default_var="default")

JOB_SCHEDULER=replace_schedule
# JOB_SCHEDULER="@once"
# JOB_SCHEDULER="30 15 * * *"
# JOB_SCHEDULER="*/1 * * * *"
QUEUE_ID = getQueueId(serverInfo)

local_tz = pendulum.timezone("Asia/Seoul")

############################## Main Section ####################################

def StartTransfer(**context):
    from MetaInfoHook import MetaInfoHook
    from FTP import FTP
    from HdfsCopy import HdfsCopy
    from Parse import Parse
    from CollectHistory import CollectHistory
    from KafkaSend import KafkaSend
    import socket
    
    execution_date = context['execution_date']
    print(f"execution_date : {execution_date}")

    try:

        kafka_send = KafkaSend()
        currentHostName = socket.gethostname()
        collectHistory = CollectHistory(INTERFACE_ID,DAG_ID,TASK_ID,currentHostName,"1",execution_date)

        mih = MetaInfoHook()
        
        interfaceInfo = mih.GetMetaInfo(INTERFACE_ID)
        print(f" interface : {interfaceInfo}")
        fileListInfo = mih.GetSourceFolderInfo(INTERFACE_ID)
        for file in fileListInfo:
            print(f"file : {file}")
            
        statusCodeInfo = mih.GetStatusCode()
        mih.dbSessionClose()

        collectHistory.setServerInfo(interfaceInfo)

        parse = Parse()

        fileTargetTime = parse.replaceTimePattern_v2(fileListInfo,interfaceInfo)
        if fileTargetTime is None:
            collectHistory.serverInfo.collect_hist_id = collectHistory.getNewUlid()
            collectHistory.serverInfo.status_cd = statusCodeInfo[2].STATUS_CD
            collectHistory.serverInfo.err_msg = statusCodeInfo[2].STATUS_NM
            kafka_send.send_to_kafka(collectHistory.serverInfo)
            raise AirflowException("Parsing Error")
        
        print(f"TargetTime : {fileTargetTime}")
        ftp = FTP(interfaceInfo,fileListInfo,fileTargetTime,kafka_send,statusCodeInfo)
        
        ftp.startFTPGet(collectHistory)

        infoDatPath = ftp.getInfoDatPath()
        print(f"info.dat Path : {infoDatPath}")
        # infoDatPath = "/data2/20230621/12/IF-T2-7022-01/info.dat"
        if infoDatPath is not None:
            hdfs_copy = HdfsCopy(kafka_send,collectHistory,interfaceInfo.FTP_SERVER_INFO.DELEMITER,statusCodeInfo)
            hdfs_copy.main(infoDatPath,stdout=True)
        else:
            raise AirflowException("No info.dat path")
        
        kafka_send.closeKafka()
    except Exception as e:
        kafka_send.closeKafka()
        raise AirflowException(str(e))

############################## DAG Setting ####################################

args = {
     'queue' : QUEUE_ID
}

with DAG(
    dag_id = DAG_ID,
    description='This code run sftp code',
    schedule_interval=JOB_SCHEDULER,
    # schedule_interval = timedelta(seconds=10),
    start_date=datetime(2023,4,28,tzinfo=local_tz),
    catchup=False,
    default_args = args,
    tags = TAGS
) as dag:
    StartSchedule = DummyOperator(task_id = 'StartSchedule')
    Start_SFTP = PythonOperator(task_id =TASK_ID, provide_context = True, python_callable=StartTransfer)
    EndSchedule = DummyOperator(task_id = 'EndSchedule')

    StartSchedule >> Start_SFTP >> EndSchedule
