from datetime import datetime
import pendulum
from airflow import DAG
from airflow.operators.python_operator import PythonOperator
from airflow.operators.dummy import DummyOperator
from airflow.exceptions import AirflowException

# from airflow.models import Variable
# import re
# import time
# from MetaInfoHook import MetaInfoHook
# from SFTP import SFTP
# from HdfsCopy import main

############################## Config Section ####################################

INTERFACE_ID=replace_dagid
TAGS=replace_tags
DAG_ID=INTERFACE_ID

# INTERFACE_ID="IF-T2-7022-01"
# TAGS=["IF-T2-7022-01","SFTP","HDFS"]
# DAG_ID=INTERFACE_ID

serverInfo=replace_serverInfo
# serverInfo="ip_net_90"

# def getJobSchedule(serverInfo):
#     parse_result = serverInfo.JOB_SCHEDULE_EXP.split("+")
    
#     if "?" in parse_result:
#         index = parse_result.index("?")
#         parse_result[index] = "*"

#     if serverInfo.INTERFACE_CYCLE == "1h":
#         return "{} * * * *".format(parse_result[1])
#     elif serverInfo.INTERFACE_CYCLE == "1d":
#         return "{} {} * * *".format(parse_result[1],parse_result[2])
#     elif serverInfo.INTERFACE_CYCLE == "1w":
#         return "{} {} * * {}".format(parse_result[1],parse_result[2],parse_result[5])
#     elif serverInfo.INTERFACE_CYCLE == "1M":    
#         return "{} {} {} * {}".format(parse_result[1],parse_result[2],parse_result[3],parse_result[5])
        
def getQueueId(serverInfo):
    from airflow.models import Variable

    return Variable.get(serverInfo,default_var="default")

JOB_SCHEDULER=replace_schedule
# JOB_SCHEDULER="@once"
QUEUE_ID = getQueueId(serverInfo)

############################## Parse Section ####################################

class ParseSection():
    def __init__(self):
        import re
        self.re = re
    
    def calculate(ifCycle, cal):
        import time
        # +9hour timezone issue
        ctime = time.strftime('%Y%m%d%H',time.localtime(time.time()))
        # a,b,c,d,e,f,g,h,i = time.localtime(time.mktime(time.strptime(ctime,'%Y%m%d%H')) - (60 * 60 * sub) + (32400))
        if ifCycle == "1d":
            a,b,c,d,e,f,g,h,i = time.localtime(time.mktime(time.strptime(ctime,'%Y%m%d%H')) - (60 * 60 * cal * 24))
            return '%04d%02d%02d%02d' % (a,b,c,d)
        else:
            a,b,c,d,e,f,g,h,i = time.localtime(time.mktime(time.strptime(ctime,'%Y%m%d%H')) - (60 * 60 * cal))
            return '%04d%02d%02d%02d' % (a,b,c,d)

    def getTimePattern(self,filePattern):
        r_p1=r'\${yyyyMM.*}'
        #find time pattern
        m_p1 = self.re.search(r_p1,filePattern)
        timepattern = m_p1.group()
        return timepattern

    def getTargetTime(self,ifCycle,timePattern):
        r_p2=r'[0-9]+'
        resultTime = None
        # find calculate time
        cal = self.re.search(r_p2,timePattern)
        if cal:
            #get calculate time
            calTime = cal.group()
            targetTime=self.calculate(ifCycle,int(calTime))
            hhPattern = "HH"
            ddPattern = "dd"
            MMPattern = "MM"
            hhCheck = self.re.search(hhPattern,timePattern)
            ddCheck = self.re.search(ddPattern,timePattern)
            MMCheck = self.re.search(MMPattern,timePattern)
            if hhCheck:
                resultTime = targetTime
            elif ddCheck:
                resultTime = targetTime[:8]
            elif MMCheck:
                resultTime = targetTime[:6]
        return resultTime

    def replaceTimePattern(self,fileListInfo,interfaceInfo):
        fileTargetTime = None

        sourceDirTimePattern = self.getTimePattern(interfaceInfo.DATA_SOURCE_DIR)
        sourceDirTimeTarget = self.getTargetTime(interfaceInfo.INTERFACE_CYCLE, sourceDirTimePattern)
        
        fileTargetTime = sourceDirTimeTarget

        interfaceInfo.DATA_SOURCE_DIR = interfaceInfo.DATA_SOURCE_DIR.replace(sourceDirTimePattern,sourceDirTimeTarget)

        for fileInfo in fileListInfo:
            fileNmTimePattern = self.getTimePattern(fileInfo.FILE_NM)
            fileNmTimeTarget = self.getTargetTime(interfaceInfo.INTERFACE_CYCLE,fileNmTimePattern)

            fileTargetTime = fileNmTimeTarget

            fileInfo.FILE_NM = fileInfo.FILE_NM.replace(fileNmTimePattern,fileNmTimeTarget)

        return fileTargetTime

############################## Main Section ####################################

def StartTransfer():
    from MetaInfoHook import MetaInfoHook
    from SFTP import SFTP
    from HdfsCopy import main
    
    mih = MetaInfoHook()
	
    fileListInfo = mih.GetSourceFolderInfo(INTERFACE_ID)
    interfaceInfo = mih.GetMetaInfo(INTERFACE_ID)

    parse = ParseSection()

    fileTargetTime = parse.replaceTimePattern(fileListInfo,interfaceInfo)

    sftp = SFTP(interfaceInfo,fileListInfo,fileTargetTime)
    
    sftp.startGet()
    
    infoDatPath = sftp.getInfoDatPath()

    if infoDatPath is not None:
        main(infoDatPath,interfaceInfo.PROTOCOL_NM,interfaceInfo.INTERFACE_CYCLE,stdout=True)
    else:
        raise AirflowException("No info.dat path")

############################## DAG Setting ####################################

args = {
     'owner' : 'seo',
     'queue' : QUEUE_ID
}

local_tz = pendulum.timezone("Asia/Seoul")

with DAG(
    dag_id = DAG_ID,
    description='This code run sftp code',
    schedule_interval=JOB_SCHEDULER,
    start_date=datetime(2023,4,28,tzinfo=local_tz),
    catchup=False,
    default_args = args,
    tags = TAGS
) as dag:
    StartSchedule = DummyOperator(task_id = 'StartSchedule')
    Start_SFTP = PythonOperator(task_id ='StartSFTP', provide_context = True, python_callable=StartTransfer)
    EndSchedule = DummyOperator(task_id = 'EndSchedule')

    StartSchedule >> Start_SFTP >> EndSchedule
