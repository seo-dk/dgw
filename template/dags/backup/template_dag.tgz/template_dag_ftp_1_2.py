from datetime import datetime, timedelta
import pendulum
from airflow import DAG
from airflow.operators.python_operator import PythonOperator
from airflow.operators.dummy import DummyOperator
from airflow.exceptions import AirflowException

############################## Config Section ####################################

INTERFACE_ID=replace_dagid
TAGS=replace_tags
DAG_ID=INTERFACE_ID

# INTERFACE_ID="IF-T2-7022-01"
# TAGS=["IF-T2-7022-01","SFTP","HDFS","DAG_TEST"]
TASK_ID = "StartTransfer"

serverInfo=replace_serverInfo
# serverInfo="ip_net_90"
        
def getQueueId(serverInfo):
    from airflow.models import Variable

    return Variable.get(serverInfo,default_var="default")

JOB_SCHEDULER=replace_schedule
# JOB_SCHEDULER="@once"
# JOB_SCHEDULER="*/1 * * * *"
QUEUE_ID = getQueueId(serverInfo)

############################## Main Section ####################################

def StartTransfer(**context):
    from MetaInfoHook import MetaInfoHook
    from FTP import FTP
    from HdfsCopy import main
    from Parse import Parse
    from CollectHistory import CollectHistory
    from KafkaSend import KafkaSend
    from StatusCode import success
    import socket
    
    DAG_RUN_ID = context['run_id']

    try:

        kafka_send = KafkaSend()
        currentHostName = socket.gethostname()
        collectHistory = CollectHistory(INTERFACE_ID,DAG_RUN_ID,TASK_ID,currentHostName,"1")

        mih = MetaInfoHook()
        
        interfaceInfo = mih.GetMetaInfo(INTERFACE_ID)
        fileListInfo = mih.GetSourceFolderInfo(INTERFACE_ID)

        mih.dbSessionClose()

        collectHistory.setServerInfo(interfaceInfo)
        collectHistory.setReTryTrue()

        parse = Parse()

        fileTargetTime = parse.replaceTimePattern(fileListInfo,interfaceInfo)

        ftp = FTP(interfaceInfo,fileListInfo,fileTargetTime,kafka_send)
        
        ftp.startSFTPGet(collectHistory)

        infoDatPath = ftp.getInfoDatPath()
        # infoDatPath = "/data2/20230621/12/IF-T2-7022-01/info.dat"
        if infoDatPath is not None:
            main(infoDatPath,collectHistory,kafka_send,stdout=True)
        else:
            raise AirflowException("No info.dat path")
        
        kafka_send.closeKafka()
    except Exception as e:
        kafka_send.closeKafka()
        raise AirflowException(str(e))

############################## DAG Setting ####################################

args = {
     'owner' : 'seo',
     'queue' : QUEUE_ID
}

local_tz = pendulum.timezone("Asia/Seoul")

with DAG(
    dag_id = "DAG_TEST",
    description='This code run sftp code',
    schedule_interval=JOB_SCHEDULER,
    # schedule_interval = timedelta(seconds=5),
    start_date=datetime(2023,4,28,tzinfo=local_tz),
    catchup=False,
    default_args = args,
    tags = TAGS
) as dag:
    StartSchedule = DummyOperator(task_id = 'StartSchedule')
    Start_SFTP = PythonOperator(task_id =TASK_ID, provide_context = True, python_callable=StartTransfer)
    EndSchedule = DummyOperator(task_id = 'EndSchedule')

    StartSchedule >> Start_SFTP >> EndSchedule
