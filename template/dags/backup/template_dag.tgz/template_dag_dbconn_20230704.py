from datetime import datetime
import pendulum
from airflow import DAG
from airflow.operators.python_operator import PythonOperator
from airflow.operators.dummy import DummyOperator
from airflow.exceptions import AirflowException


INTERFACE_ID=replace_dagid
DAG_ID=INTERFACE_ID
serverInfo=replace_serverInfo
TAGS=replace_tags
JOB_SCHEDULER=replace_schedule

def getQueueId(serverInfo):
    from airflow.models import Variable
    return Variable.get(serverInfo,default_var="default")

QUEUE_ID = getQueueId(serverInfo)
TASK_ID="StartOracle"


############################## Main Section ####################################


def StartOracle(**context):
    from MetaInfoHook import MetaInfoHook
    from OracleHook import OracleHook
    from WriteOracleResult import WriteOracleResult
    from HdfsCopy import main
    from Parse import Parse
    from CollectHistory import CollectHistory
    from KafkaSend import KafkaSend
    from StatusCode import success
    from SetPath import setOracleLocalFilePath, setOracleLocalInfoFilePath
    import socket
    import ulid

    execution_date = context['execution_date']
    
    try: 
        kafka_send = KafkaSend()
        currentHostName = socket.gethostname()
        collectHistory = CollectHistory(INTERFACE_ID,DAG_ID,TASK_ID,currentHostName,"1",execution_date)

        # get connect db info
        metaInfoHook = MetaInfoHook()
        metaInfo = metaInfoHook.GetMetaInfo(INTERFACE_ID)
        dataClassInfo = metaInfoHook.DbJsonerverInfo(metaInfo.PROTOCOL_DETAILS_JSON)

        # get sql info
        fileListInfo = metaInfoHook.GetSourceFolderInfo(INTERFACE_ID)
        
        metaInfoHook.dbSessionClose()

        collectHistory.setServerInfo(metaInfo)

        # for identifing infofiles
        new_ulid = ulid.new()
        local_info_file_path = setOracleLocalInfoFilePath(dataClassInfo, INTERFACE_ID, str(new_ulid))

        # connect to oracle
        oracleHook = OracleHook(kafka_send, collectHistory, dataClassInfo.id, dataClassInfo.pwd, dataClassInfo.ip +':' + dataClassInfo.port + '/' + dataClassInfo.sid)
        oracleHook.connectOracle()

        writeOracleResult = WriteOracleResult(kafka_send, collectHistory, metaInfo, fileListInfo)
           
        for file_info in fileListInfo:
            parse = Parse()
            time_params = parse.replaceOracleTimeParameters(file_info.DB_QUERY_INFO.time_param_regex)
            targetTime = time_params[0]
            result = oracleHook.executeSql(file_info.DB_QUERY_INFO.query, time_params)

            local_file_path = setOracleLocalFilePath(dataClassInfo, INTERFACE_ID, file_info, targetTime)
            writeOracleResult.write_to_local(local_file_path, local_info_file_path, result, file_info, targetTime)

        if local_info_file_path is not None:
            main(local_info_file_path, collectHistory, kafka_send, stdout=True)
        else:
            raise AirflowException("No info.dat path")
            
        oracleHook.closeConnection()       

        kafka_send.closeKafka()
        
    except AirflowException as e:
        raise AirflowException(str(e)) 


############################## DAG Setting ####################################

args = {
     'owner' : 'seo',
     'queue' : QUEUE_ID
}

local_tz = pendulum.timezone("Asia/Seoul")

with DAG(
    dag_id = DAG_ID,
    description='This code run oracle code',
    schedule_interval= JOB_SCHEDULER,
    start_date=datetime(2023,6,13,tzinfo=local_tz),
    catchup=False,
    default_args = args,
    tags = TAGS
) as dag:
    StartSchedule = DummyOperator(task_id = 'StartSchedule')
    OracleSchedule = PythonOperator(task_id ='OracleSchedule', provide_context = True, python_callable=StartOracle)
    EndSchedule = DummyOperator(task_id = 'EndSchedule')

    StartSchedule >> OracleSchedule >> EndSchedule
