from datetime import datetime, timedelta
import pendulum
from airflow import DAG
from airflow.operators.python_operator import PythonOperator
from airflow.operators.dummy import DummyOperator
from airflow.exceptions import AirflowException

############################## Config Section ####################################

INTERFACE_ID=replace_dagid
TAGS=replace_tags
DAG_ID=INTERFACE_ID

TASK_ID = "StartTransfer"

serverInfo=replace_serverInfo
        
def getQueueId(serverInfo):
    from airflow.models import Variable

    return Variable.get(serverInfo,default_var="default")

JOB_SCHEDULER=replace_schedule

QUEUE_ID = getQueueId(serverInfo)

local_tz = pendulum.timezone("Asia/Seoul")

############################## Main Section ####################################

def StartTransfer(**context):
    from MetaInfoHook import MetaInfoHook
    from FTP_SFTP_Manager import FTP_SFTP_Manager
    from HdfsCopy import HdfsCopy
    from Parse import Parse
    from CollectHistory import CollectHistory
    from KafkaSend import KafkaSend
    import socket
    
    execution_date = context['execution_date']
    print(f"execution_date : {execution_date}")

    try:

        currentHostName = socket.gethostname()

        mih = MetaInfoHook()
        
        interface_info = mih.GetMetaInfo(INTERFACE_ID)
        print(f" interface : {interface_info}")
        file_list_info = mih.GetSourceFolderInfo(INTERFACE_ID)
        for file in file_list_info:
            print(f"file : {file}")

        statusCodeInfo = mih.GetStatusCode()
        mih.dbSessionClose()

        kafka_send = KafkaSend(statusCodeInfo)
        collectHistory = CollectHistory(INTERFACE_ID,DAG_ID,TASK_ID,currentHostName,"1",execution_date,statusCodeInfo)
        collectHistory.setServerInfo(interface_info)

        parse = Parse()


        ## change time pattern to real time
        parse.replaceTimePattern_v2(file_list_info,interface_info)
        parse.parseNoti(interface_info)

        sftp = FTP_SFTP_Manager(interface_info,file_list_info,kafka_send)
        
        sftp.startSFTPGet(collectHistory)

        infoDatPath = sftp.getInfoDatPath()
        print(f"info.dat Path : {infoDatPath}")
        # infoDatPath = "/data2/20230621/12/IF-T2-7022-01/info.dat"
        if infoDatPath is not None:
            hdfs_copy = HdfsCopy(kafka_send,collectHistory,interface_info.FTP_SERVER_INFO.DELEMITER)
            hdfs_copy.main(infoDatPath,stdout=True)
        else:
            raise AirflowException("No info.dat path")
        
        kafka_send.closeKafka()
    except Exception as e:
        kafka_send.closeKafka()
        raise AirflowException(str(e))

############################## DAG Setting ####################################

args = {
     'owner' : 'seo',
     'queue' : QUEUE_ID
}

with DAG(
    dag_id = DAG_ID,
    description='This code run sftp code',
    schedule_interval=JOB_SCHEDULER,
    # schedule_interval = timedelta(seconds=10),
    start_date=datetime(2023,4,28,tzinfo=local_tz),
    catchup=False,
    default_args = args,
    tags = TAGS
) as dag:
    StartSchedule = DummyOperator(task_id = 'StartSchedule')
    Start_SFTP = PythonOperator(task_id =TASK_ID, provide_context = True, python_callable=StartTransfer)
    EndSchedule = DummyOperator(task_id = 'EndSchedule')

    StartSchedule >> Start_SFTP >> EndSchedule
