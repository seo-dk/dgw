from datetime import datetime, timedelta
import pendulum
from airflow import DAG
from airflow.operators.python_operator import PythonOperator
from airflow.operators.dummy import DummyOperator
from airflow.exceptions import AirflowException
from commons.File_Collect_Manager import FileCollectManager

############################## Config Section ####################################

INTERFACE_ID=replace_dagid
TAGS=replace_tags
DAG_ID=INTERFACE_ID

# DAG_ID="DAG_TEST_SFTP"
# INTERFACE_ID="C-MOIRA-SFTP-HH-0001"
# TAGS=["C-MOIRA-SFTP-HH-0001","SFTP Get","HDFS","DAG_TEST"]
TASK_ID = "StartTransfer"

serverInfo=replace_serverInfo
# serverInfo="ip_net_90"
        
def getQueueId(serverInfo):
    from airflow.models import Variable

    return Variable.get(serverInfo,default_var="default")

JOB_SCHEDULER=replace_schedule
# JOB_SCHEDULER="@once"
# JOB_SCHEDULER="10 * * * *"
# JOB_SCHEDULER="*/1 * * * *"
QUEUE_ID = getQueueId(serverInfo)

local_tz = pendulum.timezone("Asia/Seoul")

############################## Main Section ####################################

class CollectStart(FileCollectManager):
    def collect_start(self,execution_date,target_time):
        super().start_collect(INTERFACE_ID,DAG_ID,TASK_ID,execution_date,target_time)

def StartTransfer(**context):
    
    execution_date = context['execution_date']
    target_time = context['dag_run'].conf.get('target_time')
    try:
        collect_start = CollectStart()
        collect_start.collect_start(execution_date,target_time)
    except Exception as e:
        raise AirflowException(str(e))

############################## DAG Setting ####################################

args = {
     'owner' : 'mobigen',
     'queue' : QUEUE_ID,
     'email_on_failure' : True,
     'email' : ['hankgood95@mobigen.com','kyunghyunkim22@mobigen.com'],
     'retries' : 3,
     'retry_delay' : timedelta(minutes=1)
}

with DAG(
    dag_id = DAG_ID,
    description='This code run sftp code',
    schedule_interval=JOB_SCHEDULER,
    # schedule_interval = timedelta(seconds=10),
    start_date=datetime(2023,4,28,tzinfo=local_tz),
    catchup=False,
    default_args = args,
    tags = TAGS
) as dag:
    StartSchedule = DummyOperator(task_id = 'StartSchedule')
    Start_SFTP = PythonOperator(task_id =TASK_ID, provide_context = True, python_callable=StartTransfer)
    EndSchedule = DummyOperator(task_id = 'EndSchedule')

    StartSchedule >> Start_SFTP >> EndSchedule
