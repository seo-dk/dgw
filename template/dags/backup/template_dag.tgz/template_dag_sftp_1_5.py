from datetime import datetime
import pendulum
from airflow import DAG
from airflow.operators.python_operator import PythonOperator
from airflow.operators.dummy import DummyOperator
from airflow.exceptions import AirflowException

############################## Config Section ####################################

INTERFACE_ID=replace_dagid
TAGS=replace_tags
DAG_ID=INTERFACE_ID

# INTERFACE_ID="IF-T2-7022-01"
# TAGS=["IF-T2-7022-01","SFTP","HDFS","DAG_TEST"]
# DAG_ID="DAG_TEST"
TASK_ID = "StartTransfer"

serverInfo=replace_serverInfo
# serverInfo="ip_net_90"
        
def getQueueId(serverInfo):
    from airflow.models import Variable

    return Variable.get(serverInfo,default_var="default")

JOB_SCHEDULER=replace_schedule
# JOB_SCHEDULER="@once"
QUEUE_ID = getQueueId(serverInfo)

############################## Main Section ####################################

def StartTransfer():
    from MetaInfoHook import MetaInfoHook
    from SFTP import SFTP
    from HdfsCopy import main
    from Parse import Parse
    from CollectHistory import CollectHistory
    from KafkaSend import KafkaSend
    import socket
    
    kafka_send = KafkaSend()

    collectHistory = CollectHistory()

    try:
        mih = MetaInfoHook(collectHistory)
        
        interfaceInfo = mih.GetMetaInfo(INTERFACE_ID)
        fileListInfo = mih.GetSourceFolderInfo(INTERFACE_ID)

        mih.dbSessionClose()

        collectHistory = mih.getCollectHistory()

        currentHostName = socket.gethostname()

        rerun = "false"

        collectHistory.setServerInfo(interfaceInfo,DAG_ID,TASK_ID,rerun,currentHostName)

        

        parse = Parse()

        fileTargetTime = parse.replaceTimePattern(fileListInfo,interfaceInfo)

        sftp = SFTP(interfaceInfo,fileListInfo,fileTargetTime,kafka_send)
        
        sftp.startSFTPGet(collectHistory)
        
        infoDatPath = sftp.getInfoDatPath()
        # infoDatPath = "/data2/20230621/12/IF-T2-7022-01/info.dat"
        if infoDatPath is not None:
            main(infoDatPath,collectHistory,kafka_send,stdout=True)
        else:
            raise AirflowException("No info.dat path")
        
        kafka_send.closeKafka()
        
    except Exception as e:
        collectHistory.collectHistory.err_msg = str(e)[:1024]
        kafka_send.send_to_kafka(collectHistory.collectHistory)
        kafka_send.closeKafka()
        raise AirflowException(str(e))

############################## DAG Setting ####################################

args = {
     'owner' : 'seo',
     'queue' : QUEUE_ID
}

local_tz = pendulum.timezone("Asia/Seoul")

with DAG(
    dag_id = DAG_ID,
    description='This code run sftp code',
    schedule_interval=JOB_SCHEDULER,
    start_date=datetime(2023,4,28,tzinfo=local_tz),
    catchup=False,
    default_args = args,
    tags = TAGS
) as dag:
    StartSchedule = DummyOperator(task_id = 'StartSchedule')
    Start_SFTP = PythonOperator(task_id =TASK_ID, provide_context = True, python_callable=StartTransfer)
    EndSchedule = DummyOperator(task_id = 'EndSchedule')

    StartSchedule >> Start_SFTP >> EndSchedule
