from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.operators.python import BranchPythonOperator
from airflow.operators.dummy import DummyOperator
from airflow.exceptions import AirflowException
from datetime import datetime
import pendulum

############################## Config Section ####################################

local_tz = pendulum.timezone("Asia/Seoul")

"""
{
         "conf":{
                "interface_id":"IF-T1-TEST-0002",
                "source_path":"/user/samson/hive/samson_biz/user_traffic_base_1h",
                "partitions":{
                        "dt":"20230712",
                        "hh":"00",
			"nw":"4g"
                }
        }
}
"""

DAG_ID = "distcp_test_tpani"
TASK_ID = "Transfer_Distcp"

INTERFACE_ID=None
TAGS=replace_tags
DAG_ID=INTERFACE_ID

TASK_ID="Transfer_Distcp"

serverInfo=replace_serverInfo

def getQueueId(serverInfo):
    from airflow.models import Variable
    return Variable.get(serverInfo,default_var="default")

JOB_SCHEDULER=replace_schedule
QUEUE_ID = getQueueId(serverInfo)

local_tz = pendulum.timezone("Asia/Seoul")

############################## Main Section ####################################

def Transfer_Distcp(**context):
    from MetaInfoHook import MetaInfoHook
    from CollectHistory import CollectHistory
    from KafkaSend import KafkaSend
    import socket
    import paramiko

    msgD = {'-1':'argvs error','0':'success','1':'risk path delete','2':'no such dir or connect refused','3':'distcp job fail','4':'data inquality'}
    cmd_template = 'source ~/.bash_profile; /home/hadoop/bin/distcp_from_tpani.sh {0} {1}'
    server='90.90.47.63'
    username='hadoop'
    password='gkdid2023^_'
    port=22

    interface_id = context['dag_run'].conf.get('interface_id')
    src_path = context['dag_run'].conf.get('source_path')
    partitions = context['dag_run'].conf.get('partitions')
    dt=partitions['dt']
    hh=partitions['hh']
    nw=partitions['nw']

    src_path = src_path+"/dt="+dt+"/hh="+hh+"/nw="+nw

    execution_date = context['execution_date']

    try:
        # get connect db info
        metaInfoHook = MetaInfoHook()
        metaInfo = metaInfoHook.GetMetaInfo(interface_id)
        folderInfo = metaInfoHook.GetSourceFolderInfo(interface_id)
        statusCodeInfo = metaInfoHook.GetStatusCode()   
        metaInfoHook.dbSessionClose()

        currentHostName = socket.gethostname()
        collectHistory = CollectHistory(interface_id, DAG_ID, TASK_ID, currentHostName, "1", execution_date, statusCodeInfo)
        collectHistory.setServerInfo(metaInfo)

        kafka_send = KafkaSend(statusCodeInfo)

        for file_info in folderInfo:
                target_dt = dt+hh
                hdfs_dest_path = "/idcube_out" + file_info.HDFS_DIR +"/dt="+dt+"/hh="+hh+"/nw="+nw
                collectHistory.startCollectH(collect_source_seq=file_info.COLLECT_SOURCE_SEQ, 
                                             local_path="", 
                                             dest_path=hdfs_dest_path, 
                                             filenm="", 
                                             target_dt=target_dt, 
                                             partitions=partitions)

                chd = collectHistory.chdDict[file_info.COLLECT_SOURCE_SEQ]
                collectHistory.setStatusCode(chd,0)
                
                # start distcp cmd
                ssh = paramiko.SSHClient()
                ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy)
                ssh.connect(server, port=port, username=username, password=password)
                cmd_to_exec= cmd_template.format(src_path, hdfs_dest_path)
                sdtin, sdtout, sdterr = ssh.exec_command(cmd_to_exec)
                sdtout.channel.set_combine_stderr(True)

                output = sdtout.readlines()
                msg_code=output[-1].strip()
                org_msg=output[0].strip()
                
                current_time = datetime.now().isoformat()
                chd.ended_at = current_time

                if ssh is not None:
                        ssh.close()
                        del ssh, sdtin, sdtout, sdterr

                if msg_code is "0":
                        print("distcp success: ", msgD[str(msg_code)])
                        collectHistory.setStatusCode(chd, 4)
                        kafka_send.send_to_kafka(chd)           
                        kafka_send.closeKafka()
                elif msg_code is "4":
                        print("distcp success: ", msgD[str(msg_code)])
                        collectHistory.setStatusCode(chd, 5)
                        kafka_send.send_to_kafka(chd)           
                        kafka_send.closeKafka()
                else :
                        print("distcp fail: ", msgD[str(msg_code)])
                        kafka_send.sendErrorKafka(collectHistory, 9, False, "distcp failed")        
                        kafka_send.closeKafka()
                        raise AirflowException("Error at distcp")
        

    except Exception as e:
        kafka_send.closeKafka()
        raise AirflowException("Error at distcp : " + str(e)[:1024])


###################################### dag define #############################################

args = {'owner':'seo'}
with DAG(
        dag_id= DAG_ID,
        start_date=datetime(2023, 1, 1, tzinfo=local_tz),
        schedule_interval='@once',
        #schedule_interval='00 * * * *',
        catchup=False,
        tags=['TEST','DISTCP','TPANI'],
        default_args=args
) as dag:

    StartSchedule = DummyOperator(task_id="Start_Schedule")
    TransferDistcp = PythonOperator(task_id=TASK_ID, provide_context=True, python_callable=Transfer_Distcp)
    EndSchedule = DummyOperator(task_id="End_Schedule",trigger_rule='one_success')
    StartSchedule >> TransferDistcp >> EndSchedule
