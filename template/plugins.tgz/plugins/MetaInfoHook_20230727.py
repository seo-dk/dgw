from airflow.providers.mysql.hooks.mysql import MySqlHook
from airflow.exceptions import AirflowException
from airflow.models import Variable
from dataclasses import dataclass, field
from typing import Dict,List
import json
#################################################################################
@dataclass
class _DBConnectionInfoJson:
       id : str = None
       ip : str = None
       pwd : str = None
       rac : str = None
       sid : str = None
       port : str = None
       type : str = None
       dbname : str = None
       service : str = None
       local_dir : str = None

@dataclass 
class _DBQueryInfoJson:
        num_rows: str = None
        table_nm: str = None
        data_query: str = None
        count_query: str = None
        data_params: str = None
        count_params: str = None
        data_source_file_nm: str = None

@dataclass
class _FtpServerInfoJson:
    SERVER_IP : str = None
    SERVER_PORT : str = None
    DATA_LOCAL_DIR : str = None
    SERVER_USER_ID : str = None
    SERVER_USER_PWD : str = None
    DATA_SOURCE_DIR : str = None
    DATA_SOURCE_FILE_NM : str = None
    FTP_TRANS_MODE : str = None
    DELEMITER: str = None

@dataclass
class _SftpServerInfoJson:
    SERVER_IP : str = None
    SERVER_PORT : str = None
    DATA_LOCAL_DIR : str = None
    SERVER_USER_ID : str = None
    SERVER_USER_PWD : str = None
    DATA_SOURCE_DIR : str = None
    DATA_SOURCE_FILE_NM : str = None
    DELEMITER: str = None

@dataclass
class _FtpFileInfoJson:
    FILE_NM : str = None
    PARTITIONS : List[Dict[str,str]] = field(default_factory=list)
    DATA_SOURCE_FILE_NM : str = None
#################################################################################

class MetaInfoHook():

        def __init__(self):
                
                self.meta_conn_id_string = Variable.get("meta_conn_id", default_var="meta_db_1")
                self.meta_conn_ids = []
                self.meta_conn_ids = self.meta_conn_id_string.split(",")

                for mysql_conn_id in self.meta_conn_ids:
                        mysql_hook = MySqlHook(mysql_conn_id = mysql_conn_id)
                        try:
                                temp_conn = mysql_hook.get_conn()
                                self.conn = temp_conn
                                self.cursor = self.conn.cursor()
                                print(f"DB connection success. Connection Id : {mysql_conn_id}")
                                break
                        except Exception as e:
                                raise AirflowException("MetaInfoHook : DB connection failed", str(e)) 
                                

        #Source server info
        @dataclass
        class _MetaInfo:
                INTERFACE_ID: str = None
                PROTOCOL_CD: str = None
                INTERFACE_CYCLE: str = None
                JOB_SCHEDULE_EXP: str = None
                IP_NET: str = None
                SYSTEM_CD : str = None
                PROTOCOL_DETAILS_JSON: str = None
                FTP_SERVER_INFO : _FtpServerInfoJson = None
                DB_SERVER_INFO: _DBConnectionInfoJson = None


        #Source server file info
        @dataclass
        class _SourceFileInfo:
                INTERFACE_ID: str = None
                COLLECT_SOURCE_SEQ : int = None
                PROTOCOL_DETAILS_JSON: str = None
                HDFS_DIR : str = None
                FILE_INFO : _FtpFileInfoJson = None
                DB_QUERY_INFO : _DBQueryInfoJson = None

        @dataclass
        class _StatusCodeInfo:
                STATUS_CD: int = None
                STATUS_NM: str = None                

        def _setMetaInfo(self,sql):
                self.cursor.execute(sql)
                records = self.cursor.fetchall()
                return records
        

######################################################################################
        def FtpJsonServerInfo(self,protocolDetailJson):
                json_data = json.loads(protocolDetailJson)
                dataClassInfo = _FtpServerInfoJson(SERVER_IP = json_data['ip'], SERVER_PORT = json_data['port'],
                                                                DATA_LOCAL_DIR=json_data['local_dir'], SERVER_USER_ID=json_data['id'], 
                                                                SERVER_USER_PWD=json_data['pwd'], DATA_SOURCE_DIR=json_data['source_dir'],
                                                                DATA_SOURCE_FILE_NM=json_data['file_nm'],FTP_TRANS_MODE=json_data['ftp_trans_mode'],DELEMITER=json_data['delemiter'])
                return dataClassInfo   


        def SftpJsonServerInfo(self,protocolDetailJson):
                json_data = json.loads(protocolDetailJson)
                dataClassInfo = _SftpServerInfoJson(SERVER_IP = json_data['ip'], SERVER_PORT = json_data['port'],
                                                                DATA_LOCAL_DIR=json_data['local_dir'], SERVER_USER_ID=json_data['id'], 
                                                                SERVER_USER_PWD=json_data['pwd'], DATA_SOURCE_DIR=json_data['source_dir'],
                                                                DATA_SOURCE_FILE_NM=json_data['file_nm'],DELEMITER=json_data['delemiter'])
                return dataClassInfo                 
        
        def FtpSftpJsonFileInfo(self,protocolDetailJson):
                json_data = json.loads(protocolDetailJson)
                if "partitions" in json_data:
                        dataClassInfo = _FtpFileInfoJson(FILE_NM = json_data['file_nm'],PARTITIONS = json_data['partitions'], DATA_SOURCE_FILE_NM = json_data['data_source_file_nm'])
                else:
                        dataClassInfo = _FtpFileInfoJson(FILE_NM = json_data['file_nm'], DATA_SOURCE_FILE_NM = json_data['data_source_file_nm'])
                return dataClassInfo

        def DbJsonerverInfo(self,protocolDetailJson):
                json_data = json.loads(protocolDetailJson)
                dataClassInfo = _DBConnectionInfoJson(id = json_data['id'], ip = json_data['ip'], pwd = json_data['pwd'], rac = json_data['rac'],
                                                      sid = json_data['sid'], port = json_data['port'], dbname = json_data['db_name'], type = json_data['db_type'],
                                                      service = json_data['service'], local_dir = json_data['local_dir'])
                return dataClassInfo
        
        def DbJsonQueryInfo(self,protocolDetailJson):
                json_data = json.loads(protocolDetailJson)
                dataClassInfo = _DBQueryInfoJson(num_rows = json_data['num_rows'], table_nm = json_data['table_nm'], data_query = json_data['data_query'], 
                                                 count_query = json_data['count_query'], data_params = json_data['data_params'], 
                                                 count_params = json_data['count_params'], data_source_file_nm = json_data['data_source_file_nm'])
                return dataClassInfo


######################################################################################


        def GetMetaInfo(self,inf):
                try:
                        sql= """select INTERFACE_ID, PROTOCOL_CD, INTERFACE_CYCLE,
                                JOB_SCHEDULE_EXP, IP_NET, system_cd ,PROTOCOL_DETAILS_JSON
                                from collect.collect_interface5
                                where interface_id  = '%s'""" % inf
                        print(f"sql : {sql}")
                        records = self._setMetaInfo(sql)
                        for row in records:
                                self.minfo = self._MetaInfo(*row)
                
                        if self.minfo.PROTOCOL_CD == 'FTP':
                                self.minfo.FTP_SERVER_INFO = self.FtpJsonServerInfo(self.minfo.PROTOCOL_DETAILS_JSON)         
                        elif self.minfo.PROTOCOL_CD == 'SFTP':
                                self.minfo.FTP_SERVER_INFO = self.SftpJsonServerInfo(self.minfo.PROTOCOL_DETAILS_JSON)
                        elif self.minfo.PROTOCOL_CD == 'DBCONN':
                                self.minfo.DB_SERVER_INFO = self.DbJsonerverInfo(self.minfo.PROTOCOL_DETAILS_JSON)     
                        return self.minfo      
                    
                except Exception as e:
                                raise AirflowException("MetaInfoHook : SQL Query Error", str(e)) 


        def GetSourceFolderInfo(self, inf, seq_arr= None, filenm = None):
                try:
                        sql= """select INTERFACE_ID, collect_source_seq, PROTOCOL_DETAILS_JSON, HDFS_DIR
                                from collect.collect_source2
                                where interface_id = '%s'""" 
                        
                        if seq_arr is not None:
                                seq_placeholders = ','.join(['%s']*len(seq_arr))
                                sql_with_params = f"{sql} AND collect_source_seq IN ({seq_placeholders})"
                                sql = sql_with_params % (inf, *seq_arr)
                        elif filenm is not None:
                                sql_with_param = f"{sql} AND JSON_EXTRACT(protocol_details_json, '$.file_nm') = '{'%s'}'"
                                print
                                sql = sql_with_param % (inf,filenm)
                        else:
                                sql = sql % inf
                        folder_info = []

                        print(f"SQL : {sql}")

                        records = self._setMetaInfo(sql)
                        for row in records:
                                file_info = self._SourceFileInfo(*row)
                                print(f"fileInfo : {file_info}")
                                if self.minfo.PROTOCOL_CD == 'FTP' or self.minfo.PROTOCOL_CD == 'SFTP':
                                        file_info.FILE_INFO = self.FtpSftpJsonFileInfo(file_info.PROTOCOL_DETAILS_JSON)
                                elif self.minfo.PROTOCOL_CD == 'DBCONN':
                                        file_info.DB_QUERY_INFO = self.DbJsonQueryInfo(file_info.PROTOCOL_DETAILS_JSON)

                                folder_info.append(file_info)
                        return folder_info
                
                except Exception as e:
                                raise AirflowException("MetaInfoHook : SQL Query Error", str(e)) 
        
        def GetStatusCode(self):
                try:
                        sql = "select status_cd,status_nm from collect.status_code sc"
                        print(f"SQL : {sql}")
                        statuscdInfo = []
                        records = self._setMetaInfo(sql)
                        for row in records:
                                statusCd = self._StatusCodeInfo(*row)
                                statuscdInfo.append(statusCd)
                        return statuscdInfo
                except Exception as e:
                        raise AirflowException("MetaInfoHook : SQL Query Error", str(e))


        def dbSessionClose(self):
                self.cursor.close()
                self.conn.close()
                print("DB session closed")
