from pathlib import Path
import os
from airflow.exceptions import AirflowException
import ulid
class SetPath():
    def setFTPLocalPath(self,MetaInfo,fileTargetTime):
        pathDict = {}

        if fileTargetTime is not None:
            dt = fileTargetTime[:8]
            hh = fileTargetTime[8:]
            localTimePath = Path(dt,hh)     
            # if hh is not "" :
            #     localTimePath = Path(dt,hh)
            # else :
            #     localTimePath = dt
            #local tmp path
            localTmpPath = Path(MetaInfo.FTP_SERVER_INFO.DATA_LOCAL_DIR,localTimePath,MetaInfo.INTERFACE_ID)
            pathDict['localTmpPath'] = localTmpPath
        else :
            localTmpPath = Path(MetaInfo.FTP_SERVER_INFO.DATA_LOCAL_DIR,MetaInfo.INTERFACE_ID)
            pathDict['localTmpPath'] = localTmpPath

        if not os.path.exists(str(localTmpPath)):
             os.makedirs(str(localTmpPath))

        new_ulid = ulid.new()
        pathDict['infoDatPath'] = Path(localTmpPath,"info_"+str(new_ulid)+".dat")

        return pathDict       

    
    def setFTPFullPath_v2(self,MetaInfo,fileInfo,localTmpPath,matchFileNm,filePath = None):
        pathDict = {}
        if filePath is not None:
            sourceFilePath = filePath
        else:
            sourceFilePath = Path(str(MetaInfo.FTP_SERVER_INFO.DATA_SOURCE_DIR),matchFileNm)

        filenm = os.path.basename(sourceFilePath)
        pathDict['sourceFilePath'] = sourceFilePath
        tmpFullPath = Path(localTmpPath,filenm)
        pathDict['tmpFullPath'] = tmpFullPath

        pathDict['collect_source_seq'] = fileInfo.COLLECT_SOURCE_SEQ

        return pathDict
    
    def setPartitionInfo(self,fileInfo,fileTargetTime):
        partDict = {}
        dt = None
        hh = None

        if fileTargetTime is not None:
            dt = fileTargetTime[:8]
            hh = fileTargetTime[8:]
            if len(fileTargetTime) < 11:
                fileTargetTime = fileTargetTime+"00"
            if hh is not "":
                if len(hh) >= 4:
                   dictArr = [{"dt":dt},{"hm":hh}]
                else:
                    dictArr = [{"dt":dt},{"hh":hh}]
            else :
                dictArr = [{"dt":dt}]
        # will add partition in order to put in dictArr
        if fileInfo.FILE_INFO.PARTITIONS is not None:
            for partition in fileInfo.FILE_INFO.PARTITIONS:
                dictArr.append(partition)

        hdfsPath = "/idcube_out"+fileInfo.HDFS_DIR
        for item in dictArr:
            key = list(item.keys())[0]
            value = item[key]
            hdfsPath += f"/{key}={value}"

        partDict["partitions"] = dictArr
        partDict["hdfsPath"] = hdfsPath
        return partDict

    def setOracleLocalInfoFilePath(self,dataClassInfo, INTERFACE_ID):
        new_ulid = ulid.new()
        localInfoFilePath = dataClassInfo.local_dir + '/' + INTERFACE_ID + '/info' + str(new_ulid) +".dat"
        return localInfoFilePath


    def setOracleLocalFilePath(self,dataClassInfo, INTERFACE_ID, file_info, time_param, index):
        hdfsArr = file_info.HDFS_DIR.split("/")
        db_nm = hdfsArr[1]
        tb_nm = file_info.DB_QUERY_INFO.table_nm
        localFilePath = dataClassInfo.local_dir + '/airflow/' + INTERFACE_ID + '/' + db_nm + '/'+ tb_nm + '/' + tb_nm + '_' + time_param + '_' + index + '.dat'

        return localFilePath


    def setOracleResultPathVariable(self,fileInfo, localFilePath, time_param):
        pathDict = {}

        filenm = fileInfo.DB_QUERY_INFO.table_nm + '_' + time_param + ".dat"

        dt = time_param[:8]
        hh = time_param[8:]

        pathDict['tmpFullPath'] = localFilePath
        # pathDict['infoDatPath'] = Path(localFilePath,"info.dat")

        hdfsArr = fileInfo.HDFS_DIR.split("/")

        hdfsPath = Path("/","idcube_out","db="+hdfsArr[1],"tb="+hdfsArr[2],"dt="+dt,"hhmm="+hh,filenm)
        print("hdfsPath :", hdfsPath)
        pathDict['hdfsPath'] = hdfsPath

        pathDict['collect_source_seq'] = fileInfo.COLLECT_SOURCE_SEQ

        return pathDict


    def writeInfoDat(self,tmpFullPath,hdfsPath,filenm,infoDatPath,collect_source_seq):
        try:
            fullHdfsPath = Path(hdfsPath,filenm)
            #info.dat file content
            jarInfo = ','.join([str(tmpFullPath),str(fullHdfsPath),str(collect_source_seq)])
            # write local tmp file path & hdfs path to info.dat file

            if not os.path.exists(str(infoDatPath)):
                with open(str(infoDatPath),"w") as file:             
                    file.write(jarInfo)
            else:
                with open(str(infoDatPath),"a") as file:
                    file.write('\n'+ jarInfo)
        except Exception as e:
            print("Error Writing info.dat file")
            raise AirflowException("Error writing Error Writing info.dat file", str(e))


    def deleteInfoDat(self,infoDatPath):
        try:
            if os.path.exists(infoDatPath):
                os.remove(infoDatPath)
                print("info.dat file deleted...")
        except Exception as e:
            print("Error deleting info.data file...")
            raise AirflowException("Error writing Error Writing info.dat file", str(e))
        ##