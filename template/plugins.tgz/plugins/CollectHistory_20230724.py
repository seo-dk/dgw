from dataclasses import dataclass, field
from datetime import datetime, timedelta
import re
import os
import ulid
import copy
from typing import Dict,List
import urllib.parse
from StatusCode import StatusCode

@dataclass
class CollectHistoryData:
    version:str = ""
    collect_hist_id : str = ""
    retry_id_seq : int = 0
    protocol_cd:str = ""
    period : str = ""
    interface_id:str = ""
    system_cd : str = ""
    collect_source_seq :int = 0
    local_path: str = ""
    db: str = ""
    tb: str = ""
    dest_path: str = ""
    filenm : str = ""
    target_dt: str = ""
    partitions: List[Dict[str,str]] = field(default_factory=list)
    file_size : int = 0
    started_at : str = ""
    ended_at : str = ""
    task_log_url : str = ""
    err_msg : str = ""
    status_cd : str = ""
    retry : bool = False
    host_nm : str = ""

class CollectHistory():

    def __init__(self,interface_id,dag_id,task_id,host_nm,version,execution_date):
        self.statusCode = StatusCode()
        self.serverInfo = CollectHistoryData()
        self.serverInfo.interface_id = interface_id
        self.serverInfo.task_log_url = self.getUrl(dag_id,task_id,execution_date)
        self.serverInfo.host_nm = host_nm
        self.serverInfo.version = version
        self.chdDict = {}

    def getUrl(self,dag_id,task_id,execution_date):
        nine_hours = timedelta(hours=9)
        kst = execution_date + nine_hours
        execution_date_str = str(kst)
        base_url = "http://90.90.47.121:9090/log"
        excution_date_encode = urllib.parse.quote(execution_date_str[:execution_date_str.index('+')])
        logUrl = f'{base_url}?dag_id={dag_id}&task_id={task_id}&execution_date={excution_date_encode}'
        return logUrl


    def setServerInfo(self,metaInfo):
        self.serverInfo.protocol_cd=metaInfo.PROTOCOL_CD
        self.serverInfo.period=metaInfo.INTERFACE_CYCLE
        self.serverInfo.system_cd=metaInfo.SYSTEM_CD

    def setPartitionInfo(self,collect_source_seq,filenm,file_size,ended_at,src):
        # /O_TPANI_DW/5G_TRAFFIC_ANALYSIS_ENB_1H/20230605/11/2023060511_5G_COVERAGE_ENB_1H.dat
        #/user/test/sample/lte_call_kpi_01_20230418_1240.dat.lz4

        self.chdDict[collect_source_seq].filenm = filenm
        self.chdDict[collect_source_seq].file_size = file_size
        self.chdDict[collect_source_seq].ended_at = ended_at
        self.chdDict[collect_source_seq].collect_source_seq = collect_source_seq
        self.chdDict[collect_source_seq].local_path = src

    def setStatusCode(self,chd,code):
        chd.status_cd = code

    def startCollectH(self,collect_source_seq,local_path,dest_path,filenm,target_dt,partitions,collect_hist_id=None,started_at=None):
        current_time = datetime.now().isoformat()
        new_ulid = None
        chd = copy.copy(self.serverInfo)

        if collect_hist_id is None and started_at is None:
            new_ulid = ulid.new()
            chd.started_at=current_time
        else:
            new_ulid = collect_hist_id
            chd.started_at=started_at
            
        if len(target_dt) < 11:
            chd.target_dt = target_dt+"00"
        else:
            chd.target_dt = target_dt
        
        destArr = dest_path.split("/")
        
        chd.db = destArr[2][3:]
        chd.tb = destArr[3][3:]
        chd.collect_hist_id = str(new_ulid)
        chd.collect_source_seq = collect_source_seq
        chd.local_path = str(local_path)
        chd.dest_path = str(dest_path)
        chd.filenm = filenm
        chd.status_cd = self.statusCode.processing
        chd.partitions = partitions

        self.chdDict[collect_source_seq] = copy.deepcopy(chd)

    def setReTryTrue(self):
        self.serverInfo.retry = True