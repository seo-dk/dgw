import ftplib
from datetime import datetime
from SetPath import SetPath
from airflow.exceptions import AirflowException
from StatusCode import StatusCode
import re
import os

class FTP():

    def __init__(self, MetaInfo, FileListInfo, fileTargetTime, kafkaSend):
        self.MetaInfo = MetaInfo
        self.fileListInfo = FileListInfo
        self.fileTargetTime = fileTargetTime
        self.kafkaSend = kafkaSend
        self.setPath =SetPath()
        self.statusCode = StatusCode()

    def startFTPGet(self,collectHistory,files = None,filePath = None):
        try:
            with ftplib.FTP(self.MetaInfo.FTP_SERVER_INFO.SERVER_IP,timeout=30) as ftp:
                file_count = 0             
                self.setFtpConfig(ftp)
                localPathDict = self.setPath.setFTPLocalPath(self.MetaInfo,self.fileTargetTime)
                self.infoDatPath = localPathDict.get("infoDatPath")
                local_tmp = localPathDict.get("localTmpPath")
                if filePath is not None:
                    filenm = os.path.basename(filePath)
                    file_count = self.onDemand(filenm,local_tmp,filePath,collectHistory,ftp,localPathDict,file_count)
                else:
                    ftp.cwd(self.MetaInfo.FTP_SERVER_INFO.DATA_SOURCE_DIR)
                    all_files = ftp.nlst()
                    for fileInfo in self.fileListInfo:
                        match_pattern_files =  [dsfnm for dsfnm in all_files if re.match(fileInfo.FILE_INFO.DATA_SOURCE_FILE_NM, dsfnm)]
                        match_name_files = [item for item in match_pattern_files if fileInfo.FILE_INFO.FILE_NM in item]               
                        for match_file in match_name_files:
                            fullPathDict = self.setPath.setFTPFullPath_v2(self.MetaInfo,fileInfo,local_tmp,match_file)
                            partitions = self.setPath.setPartitionInfo(fileInfo,self.fileTargetTime)
                            pti = partitions.get("partitions")
                            if files is not None:
                                self.retry(collectHistory,files,fileInfo,fullPathDict,partitions,match_file)
                            else:
                                collectHistory.startCollectH(fileInfo.COLLECT_SOURCE_SEQ,fullPathDict.get("tmpFullPath"),partitions.get("hdfsPath"),match_file,self.fileTargetTime,pti)
                            chd = collectHistory.chdDict[fileInfo.COLLECT_SOURCE_SEQ]
                            self.kafkaSend.send_to_kafka(chd)
                            currentTime = datetime.now().strftime("%Y/%m/%d %H:%M")
                            file_count = self.download(ftp,localPathDict,fullPathDict,currentTime,match_file,chd,collectHistory,file_count,partitions)
                print(f"{file_count} / {len(self.fileListInfo)} success sftp get...")
        except Exception as e:
            raise AirflowException("Error at FTP : " + str(e)[:1024], collectHistory.serverInfo)
        
    def getInfoDatPath(self):
         if self.infoDatPath is not None:
            return self.infoDatPath
         else:
            return None

    def download(self,ftp,localPathDict,fullPathDict,currentTime,filenm,chd,collectHistory,file_count,partitions):
        local_tmp = localPathDict.get("localTmpPath")
        with open(fullPathDict.get("tmpFullPath"), 'wb') as local_file:
            try:
                ftp.retrbinary('RETR ' + filenm, local_file.write)
                # get file from source -> local temp dir
                print(f"Get {filenm} at time : {currentTime}, Target time : {self.fileTargetTime}")
                # write info.dat file
                self.setPath.writeInfoDat(fullPathDict.get("tmpFullPath"),partitions.get("hdfsPath"),filenm,localPathDict.get("infoDatPath"),fullPathDict.get("collect_source_seq"))
        
                print(f"FTP get success at {local_tmp}")
                file_count +=1
                return file_count       
            except Exception as e:
                print(f"Error FTP get, file : {filenm}")
                chd.err_msg="filenm : {}, {}".format(filenm,str(e)[:1024])
                collectHistory.setStatusCode(chd,self.statusCode.ftpError)
                chd.ended_at = currentTime
                # send error message to kafka
                self.kafkaSend.send_to_kafka(chd) 

    def onDemand(self,filenm,local_tmp,filePath,collectHistory,ftp,localPathDict,file_count):
        for fileInfo in self.fileListInfo:
            fullPathDict = self.setPath.setFTPFullPath_v2(self.MetaInfo,fileInfo,local_tmp,filenm,filePath)
            partitions = self.setPath.setPartitionInfo(fileInfo,self.fileTargetTime)
            pti = partitions.get("partitions")
            collectHistory.startCollectH(fileInfo.COLLECT_SOURCE_SEQ,fullPathDict.get("tmpFullPath"),partitions.get("hdfsPath"),filenm,self.fileTargetTime,pti)
            chd = collectHistory.chdDict[fileInfo.COLLECT_SOURCE_SEQ]
            self.kafkaSend.send_to_kafka(chd)
            currentTime = datetime.now().strftime("%Y/%m/%d %H:%M")
            file_count = self.download(ftp,localPathDict,fullPathDict,currentTime,filenm,chd,collectHistory,file_count,partitions)     
            return file_count
        
    def retry(self,collectHistory,files,fileInfo,fullPathDict,partitions,filenm):
            pti = partitions.get("partitions")
            index = [i for i, s in enumerate(files) if str(fileInfo.COLLECT_SOURCE_SEQ) in s]
            fileArr = files[index[0]].split(",")
            collect_hist_id = fileArr[1]
            started_at = fileArr[5]                               
            collectHistory.startCollectH(fileInfo.COLLECT_SOURCE_SEQ,fullPathDict.get("tmpFullPath"),partitions.get("hdfsPath"),filenm,self.fileTargetTime,pti,collect_hist_id,started_at)

    def setFtpConfig(self,ftp):

        ftp.login(self.MetaInfo.FTP_SERVER_INFO.SERVER_USER_ID,self.MetaInfo.FTP_SERVER_INFO.SERVER_USER_PWD)
        
        if self.MetaInfo.FTP_SERVER_INFO.FTP_TRANS_MODE == "Active":
            ftp.set_pasv(False)
        else:
            ftp.set_pasv(True)   