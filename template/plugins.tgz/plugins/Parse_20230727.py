from datetime import datetime, timedelta
from dateutil.relativedelta import relativedelta
import operator
import os

class Parse():
    def __init__(self):
        import re
        self.re = re
        self.targetTime = None

    def calculate_v2(self,num, unit):
        current_time = datetime.now()
        intNum = int(num)
        if unit == 'm':
            calTime = current_time - timedelta(minutes=intNum)
        elif unit == 'H':
            calTime = current_time - timedelta(hours=intNum)
        elif unit == 'd':
            calTime = current_time - timedelta(days=intNum)   
        elif unit == 'M':
            calTime = current_time - relativedelta(months=intNum)            
        return calTime

    def getTimePattern(self,filePattern):
        r_p1=r'\${.*?}'
        #find time pattern
        timepattern = self.re.findall(r_p1,filePattern)
        return timepattern

    def checkTimePattern(self,pattern,targetTime):
        timeStr = None
        if pattern == "${yyyy}":
            timeStr = targetTime.strftime("%Y")
        elif pattern == "${MM}":
            timeStr = targetTime.strftime("%m")
        elif pattern == "${dd}":
            timeStr = targetTime.strftime("%d")
        elif pattern == "${HH}":
            timeStr = targetTime.strftime("%H")
        elif pattern == "${yyyyMM}":
            timeStr = targetTime.strftime("%Y%m")
        elif pattern == "${yyyyMMdd}":
            timeStr = targetTime.strftime("%Y%m%d")
        elif pattern == "${yyyyMMddHH}":
            timeStr = targetTime.strftime("%Y%m%d%H")
        elif pattern == "${yyyyMMdd_HH}":
            timeStr = targetTime.strftime("%Y%m%d_%H")
        elif pattern == "${yyyyMMdd_HHmm}":
            timeStr = targetTime.strftime("%Y%m%d_%H%M")
        elif pattern == "${yyyyMMddHHmm}":
            timeStr = targetTime.strftime("%Y%m%d%H%M")
        return timeStr

    def getTargetTime_v2(self,timePattern,fileInfo,target_time = None):
        resultTime = None
        for pattern in timePattern:
            re_1 = r"\d+[dHMm]"
            re_2 = r"-\d+[dHMm]"
            cal = self.re.search(re_1,pattern)
            patternTmp = self.re.sub(re_2,"",pattern)
            if target_time:
                date_obj = datetime.strptime(target_time,"%Y%m%d%H%M")
                patternToTime = self.checkTimePattern(patternTmp,date_obj)
                self.setTargetFilenm(patternTmp,date_obj)
                return fileInfo.replace(pattern,patternToTime)
            else:    
                if cal is not None:
                    calResult = cal.group()
                    num = ""
                    unit=""
                    for char in calResult:
                        if char.isdigit():
                            num+=char
                        elif char.isalpha():
                            unit+=char                
                    #get calculate time
                    calTime=self.calculate_v2(num,unit)
                    patternToTime = self.checkTimePattern(patternTmp,calTime)
                    self.setTargetFilenm(patternTmp,calTime)
                    return fileInfo.replace(pattern,patternToTime)
                else:
                    currentTime = datetime.now()
                    patternToTime = self.checkTimePattern(patternTmp,currentTime)
                    self.setTargetFilenm(patternTmp,currentTime)
                    return fileInfo.replace(pattern,patternToTime)                  

    def setTargetFilenm(self,pattern,time):
        if self.targetTime is None:
            if "mm" in pattern:
                self.targetTime = time.strftime("%Y%m%d%H%M")
            else:
                self.targetTime = time.strftime("%Y%m%d%H")

    def replaceTimePattern_v2(self,fileListInfo,interfaceInfo,files = None):
        targetTime = None
        for fileInfo in fileListInfo:
            ##get time pattern at file data_source_file_nm
            fileSourcePattern = self.getTimePattern(fileInfo.FILE_INFO.DATA_SOURCE_FILE_NM)
            fileNmPattern = self.getTimePattern(fileInfo.FILE_INFO.FILE_NM)
            if fileSourcePattern is not None or fileNmPattern is not None:
                # enter when it's retry
                if files:
                    print("collect source seq : "+str(fileInfo.COLLECT_SOURCE_SEQ))
                    index = [i for i, s in enumerate(files) if str(fileInfo.COLLECT_SOURCE_SEQ) in s]
                    fileArr = files[index[0]].split(",")
                    targetTime = fileArr[3]
                    if fileSourcePattern:
                        fileInfo.FILE_INFO.DATA_SOURCE_FILE_NM = self.getTargetTime_v2(fileSourcePattern,fileInfo.FILE_INFO.DATA_SOURCE_FILE_NM,targetTime)
                    if fileNmPattern:
                        fileInfo.FILE_INFO.FILE_NM = self.getTargetTime_v2(fileNmPattern,fileInfo.FILE_INFO.FILE_NM,targetTime)
                else:
                    if fileSourcePattern:
                        fileInfo.FILE_INFO.DATA_SOURCE_FILE_NM = self.getTargetTime_v2(fileSourcePattern,fileInfo.FILE_INFO.DATA_SOURCE_FILE_NM)
                    if fileNmPattern:
                        fileInfo.FILE_INFO.FILE_NM = self.getTargetTime_v2(fileNmPattern,fileInfo.FILE_INFO.FILE_NM)
            print(fileInfo)
        
        sourceDirTimePattern = self.getTimePattern(interfaceInfo.FTP_SERVER_INFO.DATA_SOURCE_DIR)
        if sourceDirTimePattern:
            if files:
                interfaceInfo.FTP_SERVER_INFO.DATA_SOURCE_DIR = self.getTargetTime_v2(sourceDirTimePattern,interfaceInfo.FTP_SERVER_INFO.DATA_SOURCE_DIR,targetTime)
            else:
                interfaceInfo.FTP_SERVER_INFO.DATA_SOURCE_DIR = self.getTargetTime_v2(sourceDirTimePattern,interfaceInfo.FTP_SERVER_INFO.DATA_SOURCE_DIR)
        print(interfaceInfo)    
        return self.targetTime

    # Oracle
    def getTimeValue(self, timePattern, timeValue, operatorStr):
        #list = [1y, 1M, 1d, 10m]
        timeValue = datetime.strptime(timeValue, "%Y%m%d%H%M")

        operator_mapping = {
            "+": operator.add,
            "-": operator.sub
        }

        operator_func = None

        if operatorStr == '+':
            operator_func = operator_mapping['+']
        else:
            operator_func = operator_mapping['-']

        for value in timePattern:
            numList = self.re.findall(r'\d+', value)
            num = int(numList[0])

            charList = self.re.findall(r'[a-zA-Z]', value)
            char = charList[0]

            if char in "y":
                timeValue = operator_func(timeValue, relativedelta(years=num))
            elif char in "M":
                timeValue = operator_func(timeValue, relativedelta(months=num))
            elif char in "d":
                timeValue = operator_func(timeValue, timedelta(days=num))
            elif char in "H":
                timeValue = operator_func(timeValue, timedelta(hours=num))
            elif char in "m":
                timeValue = operator_func(timeValue, timedelta(minutes=num))

        result_time = timeValue.strftime('%Y%m%d%H%M')

        return result_time

    # Oracle       
    def getRerunTimeVlaue(self, timeParam, tagetTime):
        #list = [1y, 1M, 1d, 10m]
        tagetTime = datetime.strptime(tagetTime, "%Y%m%d%H%M")

        #get pastTime
        for value in timeParam:
            print("value ", value)

            numList = self.re.findall(r'\d+', value)
            num = int(numList[0])

            charList = self.re.findall(r'[a-zA-Z]', value)
            char = charList[0]

            if char in "y":
                tagetTime = tagetTime + relativedelta(years=num) 
            elif char in "M":
                tagetTime = tagetTime + relativedelta(months=num) 
            elif char in "d":
                tagetTime = tagetTime + timedelta(days=num) 
            elif char in "H":
                tagetTime = tagetTime + timedelta(hours=num) 
            elif char in "m":
                tagetTime = tagetTime + timedelta(minutes=num) 

        result_time = tagetTime.strftime('%Y%m%d%H%M')

        return result_time
    

    def getSqlParams(self, querys_params):
        #querys_params = ["STRING", "10", "${yyyyMMddHH-10M}','${yyyyMMddHH}", "SEF", "${yyyyMMddHH-3M}'] or  ["STRING", "NUM"]
        result_dic = {}
        param_reuslt = []

        print("querys_params: ", querys_params)
        current_time = datetime.now() - timedelta(minutes=5) 
        current_time = current_time.strftime('%Y%m%d%H%M')
        targetTime = current_time

        for data_param in querys_params:
            if "$" in data_param:
                # querys_params = ${yyyyMMddHH-10M}
                if "-" in data_param:
                    matches = self.re.findall(r'\d+\w', data_param)
                    calculated_time = self.getTimeValue(matches, current_time, "-")
                    param_reuslt.append(calculated_time)
                    targetTime = calculated_time
                # querys_params = ${yyyyMMddHH}
                else:
                    param_reuslt.append(current_time)
                    targetTime = current_time
            else:
                print("getSqlParams  append data_param: ", data_param)
                param_reuslt.append(data_param)
        
        result_dic['param_result'] = param_reuslt
        result_dic['target_time'] = targetTime

        return result_dic

    
    def getQueryUsingRowNum(self, data_query, start_row_num, end_row_num):
        # select org.*
        #   from (select rownum as rn, CTIME from PM_LINK_ENB_KPI_1H WHERE EVENT_TIME=to_date('2023072010','yyyymmddhh24')) org
        #   WHERE rn between 3 and 10;

        select_index = data_query.lower().index("select")
        sub_query = "SELECT ROWNUM AS rn," + data_query[select_index + len("select"):]
        
        params = []
        params.append(sub_query)
        params.append(start_row_num)
        sql = "SELECT * FROM ({}) WHERE rn > {} AND rn <= {}"

        if end_row_num == -1:
            sql = "SELECT * FROM ({}) WHERE rn > {}"     
        else:
            params.append(end_row_num)
        
        formatted_sql = sql.format(*params)
        print("getQueryUsingRowNum: ", formatted_sql)

        return formatted_sql


    def replaceOracleTimeParameters(self, timeParameters):
        #"${yyyyMMdd HHmm-1y1M1d10m},${yyyyMMdd HHmm-30d}"
        timeParamList = timeParameters.split(",")
        returnList = []
        
        #"${yyyyMMdd HHmm-1y1M1d10m}
        for timeParam in timeParamList:
            current_time = datetime.now() - timedelta(minutes=5) 
            current_time = current_time.strftime('%Y%m%d%H%M')

            if "-" in timeParam:
                matches = self.re.findall(r'\d+\w', timeParam)
                returnList.append(self.getTimeValue(matches, current_time, "-"))

            else:
                returnList.append(current_time)

        return returnList
    
    
    # Oracle
    def getRerunTimeParameters(self, timeParameters, tagetTime):
        # tagetTime = 'yyyyMMddHHmm'
        returnList = []

        # case: timeParameters len = 1
        if "," not in timeParameters:
            returnList.append(tagetTime)

        # case: timeParameters len = 2        
        else:
            #timeParameters = "${yyyyMMdd HHmm-1y1M1d10m},${yyyyMMdd HHmm-30d}"
            timeParamList = timeParameters.split(",")
            #"${yyyyMMdd HHmm-1y1M1d10m}
            matches = self.re.findall(r'\d+\w', timeParamList[0])
            pastTargetTime = self.getTimeValue(matches, tagetTime, "+")
            returnList.append(tagetTime)

            #${yyyyMMdd HHmm-30d}"
            if "-" in timeParamList[1]:
                matches = self.re.findall(r'\d+\w', timeParamList[1])
                pastTime = self.getTimeValue(matches, pastTargetTime, "-")
                returnList.append(pastTime)

            #${yyyyMMdd HHmm}
            else:
                returnList.append(pastTargetTime)

        return returnList
    
    def getFilenm(self,filePath):
        filenm = os.path.basename(filePath)

        datePattern = r"\d{6,}"
        filenm = self.re.sub(datePattern,"",filenm)
        extPtn = r"\.\w+$"
        filenm = self.re.sub(extPtn,"",filenm)
        rmUndB = r"^_|_$"
        filenm = self.re.sub(rmUndB,"",filenm)
        return filenm