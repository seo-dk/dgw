import json
from kafka import KafkaProducer, KafkaAdminClient
from dataclasses import asdict

KAFKA_SERVER = 'gw-kafka-001:9092'
TOPIC_NAME = "hdfs_load_completion"

class KafkaSend():
    def __init__(self):
        self.producer = KafkaProducer(acks=1, security_protocol='SASL_PLAINTEXT', sasl_mechanism='SCRAM-SHA-256', sasl_plain_username='admin',sasl_plain_password='shfkd2023^_'
        , bootstrap_servers=[KAFKA_SERVER], value_serializer=lambda x: x.encode('utf-8'))
        self.partitonCount = len(self.producer.partitions_for(TOPIC_NAME))

    def send_to_kafka(self, collectHistory):
        try:
            partitionNum = self.ulid_to_part(collectHistory.collect_hist_id,self.partitonCount)
            jsondata = json.dumps(asdict(collectHistory))
            self.producer.send(TOPIC_NAME, jsondata,partition=partitionNum)
            print(f"kafka message produced: {jsondata}")
        except Exception as e:
            print(f"KafkaError : {e}")
    
    def closeKafka(self):
        self.producer.close()
    
    def ulid_to_part(self,ulid_value, n):
        base32_chars = "0123456789ABCDEFGHJKMNPQRSTVWXYZ"
        last_four_chars = ulid_value[-4:]
        number = 0
        for char in last_four_chars:
            number = number * 32 + base32_chars.index(char)
        return number % n
    

    
    