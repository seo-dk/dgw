from pyarrow.fs import HadoopFileSystem, FileType
import pyarrow.lib as lib
import concurrent.futures
import os
# import threading
import glob
from airflow.exceptions import AirflowException
from datetime import datetime
from StatusCode import StatusCode
from SetPath import SetPath

hadoop_home = '/local/HADOOP'

pattern = [hadoop_home + '/share/hadoop/' + d + '/**/*.jar' for d in ['hdfs', 'common']]
hdfs_cp = ':'.join(file for p in pattern for file in glob.glob(p, recursive=True))

os.environ['CLASSPATH'] = ':'.join([hadoop_home + '/etc/hadoop:', hdfs_cp])
os.environ['LD_LIBRARY_PATH'] = os.getenv('LD_LIBRARY_PATH', '') + ':' + hadoop_home + '/lib/native:'

class HdfsCopy:
    def __init__(self,kafkaSend, collectHistory,delemiter,statusCode ,port=8020, user='hadoop'):
        
        host = "default"
        self.kafka = kafkaSend
        self.statusCode = statusCode
        try:
            self._hdfs = HadoopFileSystem(host, port=port, user=user)
            self.collectHistory = collectHistory
            self.delemiter = delemiter
        except:
            self.sendErrorKafka(collectHistory,4)
            raise AirflowException("HDFS connection failed")
        self.producer_conf = { 'bootstrap.servers' : 'tvdn-012-061:9093' }
        self.setPath = SetPath()


    def copy(self, src, dest, ulid, stdout):
        chd = self.collectHistory.chdDict[ulid]
        encodings = ['utf-8','euc-kr']
        try:
            for encoding in encodings :
                try:
                    with open(src, 'r', encoding=encoding) as local_file:
                        data = local_file.read()
                        break
                except UnicodeDecodeError:
                    print(f"Cannot encode file {src} with {encoding}")
                    continue
            
            modifiedData = data.replace(self.delemiter,"\036")

            filenm = os.path.basename(dest)
            destpath = os.path.dirname(dest.strip())
            
            fileinfo = self._hdfs.get_file_info(destpath)
            
            if fileinfo.type == FileType.Directory:
                self._hdfs.create_dir(destpath, recursive=True)
            startTime = datetime.now()
            with self._hdfs.open_output_stream(dest) as hdfs_file:
                hdfs_file.write(modifiedData.encode('utf-8'))
            endTime = datetime.now()
            timeTaken = endTime - startTime
            print(f"File : {filenm}, Time taken : {timeTaken}")
            current_time = datetime.now().isoformat()
            file_size = self._hdfs.get_file_info(dest).size
            self.collectHistory.setPartitionInfo(ulid,filenm,file_size,current_time,src)
            self.collectHistory.setStatusCode(chd,self.statusCode[0].STATUS_CD)
            self.kafka.send_to_kafka(chd)
            
            if stdout:
                print(f"Succ : {src} ==> {dest}")
            return "Success"
        except Exception as e:
            if stdout:
                print(f"Fail : {src} ==> {dest}")
            filenm = os.path.basename(dest)
            chd.status_cd = self.statusCode[3].STATUS_CD
            current_time = datetime.now().isoformat()
            chd.ended_at = current_time
            chd.err_msg = f"Error file : {filenm} "+str(e)
            self.kafka.send_to_kafka(chd)
            # raise CollectException(f"Error file : {filenm} "+str(e),chd)

    def main(self,info,stdout=False):
        try:

            #read info.dat file
            with open(info, 'r') as f:
                lines = f.readlines() 

            results = []
            with concurrent.futures.ThreadPoolExecutor(max_workers=10) as executor:
                futures = [executor.submit(self.copy, src, dest, ulid, stdout) 
                        for src, dest, ulid in [line.strip().split(",") for line in lines]]
                for future in concurrent.futures.as_completed(futures):
                    results.append(future.result())

            self.setPath.deleteInfoDat(info)

            resultCount = results.count("Success")
            total = len(results)
            response_code = results.count("Success") / len(results)
            if response_code != 1:
                print(f"{resultCount} / {total} has been stored at hdfs")
        except FileNotFoundError:
            print("0 file has been download... s/ftp fail error...")        
        except Exception as e:
            self.setPath.deleteInfoDat(info)
            raise AirflowException("Error at S/FTP : " + str(e)[:1024])
        
    def sendErrorKafka(self, collectHistory,num):
        collectHistory.serverInfo.collect_hist_id = collectHistory.getNewUlid()
        collectHistory.serverInfo.status_cd = self.statusCode[num].STATUS_CD
        collectHistory.serverInfo.err_msg = self.statusCode[num].STATUS_NM
        collectHistory.serverInfo.ended_at = datetime.now().isoformat()
        self.kafkaSend.send_to_kafka(collectHistory.serverInfo)   
        
#response_code = main(INFO_DAT,"SFTP","1h",stdout=True)
#print("Response Code: ", response_code)

