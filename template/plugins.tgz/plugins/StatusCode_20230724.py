class StatusCode():
    processing = 6001
    metaInfoHookError = 1
    ftpError = 6002
    hdfsError = 6004
    oracleError = 5
    distcpError = 6
    success = 6005
