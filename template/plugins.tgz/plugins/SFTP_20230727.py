import paramiko
from datetime import datetime
from SetPath import SetPath
from airflow.exceptions import AirflowException
from StatusCode import StatusCode
import re
import os
    
class SFTP():

    def __init__(self, MetaInfo, FileListInfo, fileTargetTime,kafkaSend,statusCodeInfo):
        self.MetaInfo = MetaInfo
        self.fileListInfo = FileListInfo
        self.fileTargetTime = fileTargetTime
        self.kafkaSend = kafkaSend
        self.setPath = SetPath()
        self.statusCode = statusCodeInfo

    def startSFTPGet(self, collectHistory,files = None,filePath = None):
        try:
            with paramiko.SSHClient() as ssh_client:
                ssh_client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
                print("Start getting files from source server...")
                print(f"InterFaceID : {self.MetaInfo.INTERFACE_ID}, Source server : {self.MetaInfo.FTP_SERVER_INFO.SERVER_IP}")
                print(f"Source dir : {self.MetaInfo.FTP_SERVER_INFO.DATA_SOURCE_DIR}")
                print(f"Target file time : {self.fileTargetTime}")
                ssh_client.connect(hostname=self.MetaInfo.FTP_SERVER_INFO.SERVER_IP,port=self.MetaInfo.FTP_SERVER_INFO.SERVER_PORT,
                                   username=self.MetaInfo.FTP_SERVER_INFO.SERVER_USER_ID, password=self.MetaInfo.FTP_SERVER_INFO.SERVER_USER_PWD,timeout=30)
                
                with ssh_client.open_sftp() as sftp:
                    count = 0

                    localPathDict = self.setPath.setFTPLocalPath(self.MetaInfo,self.fileTargetTime)
                    self.infoDatPath = localPathDict.get("infoDatPath")
                    local_tmp = localPathDict.get("localTmpPath")

                    if filePath is not None:
                        filenm = os.path.basename(filePath)
                        for fileInfo in self.fileListInfo:
                            fullPathDict = self.setPath.setFTPFullPath_v2(self.MetaInfo,fileInfo,local_tmp,filenm,filePath)
                            partitions = self.setPath.setPartitionInfo(fileInfo,self.fileTargetTime)
                            pti = partitions.get("partitions")
                            ulid = collectHistory.startCollectH(fileInfo.COLLECT_SOURCE_SEQ,fullPathDict.get("tmpFullPath"),partitions.get("hdfsPath"),filenm,self.fileTargetTime,pti,self.statusCode)
                            chd = collectHistory.chdDict[ulid]
                            self.kafkaSend.send_to_kafka(chd)

                            count = self.download(sftp,localPathDict,fullPathDict,filenm,chd,count,partitions,ulid)
                        if count == 0:
                            self.sendErrorKafka(collectHistory,5)
                    else:
                        all_files = sftp.listdir(self.MetaInfo.FTP_SERVER_INFO.DATA_SOURCE_DIR)

                        for fileInfo in self.fileListInfo:
                            # find pattern match file with data_source_file_nm in file list
                            match_pattern_files =  [dsfnm for dsfnm in all_files if re.match(fileInfo.FILE_INFO.DATA_SOURCE_FILE_NM, dsfnm)]
                            # find filenm match file with data_source_file_nm in match_pattern_files
                            match_name_files = [item for item in match_pattern_files if fileInfo.FILE_INFO.FILE_NM in item]
                            for match_file in match_name_files:
                                # set Path variable 
                                # I should set patition and hdfs Path at here
                                fullPathDict = self.setPath.setFTPFullPath_v2(self.MetaInfo,fileInfo,local_tmp,match_file)
                                partitions = self.setPath.setPartitionInfo(fileInfo,self.fileTargetTime)
                                pti = partitions.get("partitions")
                                # enter when it's retry
                                if files is not None:
                                    index =  [i for i, s in enumerate(files) if str(fileInfo.COLLECT_SOURCE_SEQ) in s]
                                    fileArr = files[index[0]].split(",")
                                    collect_hist_id = fileArr[1]
                                    started_at = fileArr[5]
                                    print(f"started_at : {started_at}")
                                    # set info with retry parameter and send kafka
                                    ulid = collectHistory.startCollectH(fileInfo.COLLECT_SOURCE_SEQ,fullPathDict.get("tmpFullPath"),partitions.get("hdfsPath"),match_file,self.fileTargetTime,pti,self.statusCode,collect_hist_id,started_at)
                                else:
                                    ulid = collectHistory.startCollectH(fileInfo.COLLECT_SOURCE_SEQ,fullPathDict.get("tmpFullPath"),partitions.get("hdfsPath"),match_file,self.fileTargetTime,pti,self.statusCode)

                                # get collectHistory by collect_source_seq
                                chd = collectHistory.chdDict[ulid]
                                self.kafkaSend.send_to_kafka(chd)

                                count = self.download(sftp,localPathDict,fullPathDict,match_file,chd,collectHistory,count,partitions,ulid)

                    if count == 0:
                        self.sendErrorKafka(collectHistory,5)
                    print(f"{count} / {len(self.fileListInfo)} success sftp get...")
            

        except Exception as e:
            self.sendErrorKafka(collectHistory,2)
            raise AirflowException("Error at SFTP : ",str(e)[:1024])

    def sendErrorKafka(self, collectHistory,num):
        collectHistory.serverInfo.collect_hist_id = collectHistory.getNewUlid()
        collectHistory.serverInfo.status_cd = self.statusCode[num].STATUS_CD
        collectHistory.serverInfo.err_msg = self.statusCode[num].STATUS_NM
        collectHistory.serverInfo.ended_at = datetime.now().isoformat()
        self.kafkaSend.send_to_kafka(collectHistory.serverInfo)   

    def getInfoDatPath(self):
         if self.infoDatPath is not None:
            return self.infoDatPath
         else:
            return None
    
    def getParitionInfo(self):
        return self.partitions
    
    def download(self,sftp,localPathDict,fullPathDict,filenm,chd,collectHistory,count,partitions,ulid):
        local_tmp = localPathDict.get("localTmpPath")
        print(f"local_tmp : {local_tmp}")
        try:
            startTime = datetime.now()
            sftp.get(str(fullPathDict.get("sourceFilePath")),str(fullPathDict.get("tmpFullPath")))
            endTime = datetime.now()
            timeTaken = endTime - startTime
            print(f"Get {filenm}, Time Taken:{timeTaken}, Target time : {self.fileTargetTime} ")
            self.setPath.writeInfoDat(fullPathDict.get("tmpFullPath"),partitions.get("hdfsPath"),filenm,localPathDict.get("infoDatPath"),ulid)
            
            print(f"SFTP get success at {local_tmp}")
            count+=1
            return count
        except Exception as e:
            print(f"Error SFTP get, file : {filenm}")
            chd.err_msg="filenm : {}, {}".format(filenm,str(e)[:1024])
            current_time = datetime.now().isoformat()
            chd.ended_at = current_time                            
            collectHistory.setStatusCode(chd,self.statusCode[2].STATUS_CD)
            # set Error info and send to kafka
            self.kafkaSend.send_to_kafka(chd)