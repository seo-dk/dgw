import ftplib
from datetime import datetime
from SetPath import SetPath
from airflow.exceptions import AirflowException
from StatusCode import StatusCode
import re
import os

class FTP():

    def __init__(self, MetaInfo, FileListInfo, fileTargetTime, kafkaSend,statusCode):
        self.MetaInfo = MetaInfo
        self.fileListInfo = FileListInfo
        self.fileTargetTime = fileTargetTime
        self.kafkaSend = kafkaSend
        self.setPath =SetPath()
        self.statusCode = statusCode

    def startFTPGet(self,collectHistory,files = None,filePath = None):
        try:
            with ftplib.FTP(self.MetaInfo.FTP_SERVER_INFO.SERVER_IP,timeout=30) as ftp:
                file_count = 0             
                self.setFtpConfig(ftp)
                localPathDict = self.setPath.setFTPLocalPath(self.MetaInfo,self.fileTargetTime)
                self.infoDatPath = localPathDict.get("infoDatPath")
                local_tmp = localPathDict.get("localTmpPath")
                if filePath is not None:
                    filenm = os.path.basename(filePath)
                    file_count = self.onDemand(filenm,local_tmp,filePath,collectHistory,ftp,localPathDict,file_count)
                else:
                    ftp.cwd(self.MetaInfo.FTP_SERVER_INFO.DATA_SOURCE_DIR)
                    all_files = ftp.nlst()
                    for fileInfo in self.fileListInfo:
                        match_pattern_files =  [dsfnm for dsfnm in all_files if re.match(fileInfo.FILE_INFO.DATA_SOURCE_FILE_NM, dsfnm)]
                        if len(match_pattern_files) == 1 and match_pattern_files[0] == fileInfo.FILE_INFO.DATA_SOURCE_FILE_NM:
                            file_count = self.setPathAndGet(fileInfo,local_tmp,match_pattern_files[0],collectHistory,files,file_count,ftp,localPathDict)
                        else:
                            match_name_files = [item for item in match_pattern_files if fileInfo.FILE_INFO.FILE_NM in item]
                            for match_file in match_name_files:
                                file_count = self.setPathAndGet(fileInfo,local_tmp,match_file,collectHistory,files,file_count,ftp,localPathDict)
                
                print(f"{file_count} / {len(self.fileListInfo)} success ftp get...")
                self.checkFileCount(collectHistory,file_count)            
        except Exception as e:
            self.sendErrorKafka(collectHistory,8)
            raise AirflowException("Error at FTP : " + str(e)[:1024], collectHistory.serverInfo)

    def sendErrorKafka(self, collectHistory,num):
        collectHistory.serverInfo.collect_hist_id = collectHistory.getNewUlid()
        collectHistory.serverInfo.status_cd = self.statusCode[num].STATUS_CD
        collectHistory.serverInfo.err_msg = self.statusCode[num].STATUS_NM
        collectHistory.serverInfo.ended_at = datetime.now().isoformat()
        self.kafkaSend.send_to_kafka(collectHistory.serverInfo)        

    def checkFileCount(self,collectHistory,fileCount):
        if fileCount == 0:
            self.sendErrorKafka(collectHistory,5)     

    def getInfoDatPath(self):
         if self.infoDatPath is not None:
            return self.infoDatPath
         else:
            return None

    def download(self,ftp,localPathDict,fullPathDict,filenm,chd,collectHistory,file_count,partitions,ulid):
        local_tmp = localPathDict.get("localTmpPath")
        with open(fullPathDict.get("tmpFullPath"), 'wb') as local_file:
            try:
                startTime = datetime.now()
                ftp.retrbinary('RETR ' + filenm, local_file.write)
                endTime = datetime.now()
                timeTaken = endTime - startTime
                # get file from source -> local temp dir
                print(f"Get {filenm}, Time taken :{timeTaken} , Target time : {self.fileTargetTime}")
                # write info.dat file
                self.setPath.writeInfoDat(fullPathDict.get("tmpFullPath"),partitions.get("hdfsPath"),filenm,localPathDict.get("infoDatPath"),ulid)
        
                print(f"FTP get success at {local_tmp}")
                file_count +=1
                return file_count       
            except Exception as e:
                print(f"Error FTP get, file : {filenm}")
                chd.err_msg="filenm : {}, {}".format(filenm,str(e)[:1024])
                collectHistory.setStatusCode(chd,self.statusCode[1].STATUS_CD)
                chd.ended_at = datetime.now().isoformat()
                # send error message to kafka
                self.kafkaSend.send_to_kafka(chd) 

    def setPathAndGet(self,fileInfo,local_tmp,filenm,collectHistory,files,file_count,ftp,localPathDict):
        fullPathDict = self.setPath.setFTPFullPath_v2(self.MetaInfo,fileInfo,local_tmp,filenm)
        partitions = self.setPath.setPartitionInfo(fileInfo,self.fileTargetTime)
        pti = partitions.get("partitions")
        ulid = None
        if files is not None:
            ulid = self.retry(collectHistory,files,fileInfo,fullPathDict,partitions,filenm)
        else:
            ulid = collectHistory.startCollectH(fileInfo.COLLECT_SOURCE_SEQ,fullPathDict.get("tmpFullPath"),partitions.get("hdfsPath"),filenm,self.fileTargetTime,pti,self.statusCode)
        chd = collectHistory.chdDict[ulid]
        self.kafkaSend.send_to_kafka(chd)
        file_count = self.download(ftp,localPathDict,fullPathDict,filenm,chd,collectHistory,file_count,partitions,ulid)
        return file_count     

    def onDemand(self,filenm,local_tmp,filePath,collectHistory,ftp,localPathDict,file_count):
        for fileInfo in self.fileListInfo:
            fullPathDict = self.setPath.setFTPFullPath_v2(self.MetaInfo,fileInfo,local_tmp,filenm,filePath)
            partitions = self.setPath.setPartitionInfo(fileInfo,self.fileTargetTime)
            pti = partitions.get("partitions")
            ulid = collectHistory.startCollectH(fileInfo.COLLECT_SOURCE_SEQ,fullPathDict.get("tmpFullPath"),partitions.get("hdfsPath"),filenm,self.fileTargetTime,pti,self.statusCode)
            chd = collectHistory.chdDict[ulid]
            self.kafkaSend.send_to_kafka(chd)
            currentTime = datetime.now().strftime("%Y/%m/%d %H:%M")
            file_count = self.download(ftp,localPathDict,fullPathDict,currentTime,filenm,chd,collectHistory,file_count,partitions,ulid)     
            return file_count
        
    def retry(self,collectHistory,files,fileInfo,fullPathDict,partitions,filenm):
        pti = partitions.get("partitions")
        index = [i for i, s in enumerate(files) if str(fileInfo.COLLECT_SOURCE_SEQ) in s]
        fileArr = files[index[0]].split(",")
        collect_hist_id = fileArr[1]
        started_at = fileArr[5]                               
        ulid = collectHistory.startCollectH(fileInfo.COLLECT_SOURCE_SEQ,fullPathDict.get("tmpFullPath"),partitions.get("hdfsPath"),filenm,self.fileTargetTime,pti,self.statusCode,collect_hist_id,started_at)
        return ulid
    
    def setFtpConfig(self,ftp):

        ftp.login(self.MetaInfo.FTP_SERVER_INFO.SERVER_USER_ID,self.MetaInfo.FTP_SERVER_INFO.SERVER_USER_PWD)
        
        if self.MetaInfo.FTP_SERVER_INFO.FTP_TRANS_MODE == "Active":
            ftp.set_pasv(False)
        else:
            ftp.set_pasv(True)   