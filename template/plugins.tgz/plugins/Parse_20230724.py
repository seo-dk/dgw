from datetime import datetime, timedelta
from dateutil.relativedelta import relativedelta
import operator
import os

class Parse():
    def __init__(self):
        import re
        self.re = re

    def calculate_v2(self,num, unit):
        current_time = datetime.now()
        intNum = int(num)
        if unit == 'M':
            calTime = current_time - relativedelta(months=intNum)
        elif unit == 'd':
            calTime = current_time - timedelta(days=intNum)
        elif unit == 'H':
            calTime = current_time - timedelta(hours=intNum)

        format_time = calTime.strftime("%Y%m%d%H")

        return format_time

    def getTimePattern(self,filePattern):
        r_p1=r'\${yyyyMM.*}'
        #find time pattern
        m_p1 = self.re.search(r_p1,filePattern)
        if m_p1 is not None:
            timepattern = m_p1.group()
        else :
            timepattern = None
        return timepattern

    def getTargetTime_v2(self,timePattern):
        re_1 = r"\d+[dHM]"
        resultTime = None
        cal = None
        if timePattern is not None:
            cal = self.re.search(re_1,timePattern)
            calResult = cal.group()
            num = ""
            unit=""
            for char in calResult:
                if char.isdigit():
                    num+=char
                elif char.isalpha():
                    unit+=char
            if cal:
                #get calculate time
                targetTime=self.calculate_v2(num,unit)
                hhPattern = "HH"
                ddPattern = "dd"
                MMPattern = "MM"
                hhCheck = self.re.search(hhPattern,timePattern)
                ddCheck = self.re.search(ddPattern,timePattern)
                MMCheck = self.re.search(MMPattern,timePattern)
                if hhCheck:
                    resultTime = targetTime
                elif ddCheck:
                    resultTime = targetTime[:8]
                elif MMCheck:
                    resultTime = targetTime[:6]
            else:
                currentTime = datetime.now()
                formatTime = currentTime.strftime('%Y%m%d%H')
                resultTime = formatTime
        return resultTime                    

    def replaceTimePattern_v2(self,fileListInfo,interfaceInfo,files = None):
        targetTime = None
        fileTargetTime = None
        for fileInfo in fileListInfo:
            ##get time pattern at file data_source_file_nm
            fileSourcePattern = self.getTimePattern(fileInfo.FILE_INFO.DATA_SOURCE_FILE_NM)
            fileNmPattern = self.getTimePattern(fileInfo.FILE_INFO.FILE_NM)
            if fileSourcePattern is not None or fileNmPattern is not None:
                # enter when it's retry
                if files is not None:
                    print("collect source seq : "+str(fileInfo.COLLECT_SOURCE_SEQ))
                    index = [i for i, s in enumerate(files) if str(fileInfo.COLLECT_SOURCE_SEQ) in s]
                    fileArr = files[index[0]].split(",")
                    targetTime = fileArr[3][:10]
                    fileTargetTime = targetTime
                    if fileSourcePattern:
                        fileInfo.FILE_INFO.DATA_SOURCE_FILE_NM = fileInfo.FILE_INFO.DATA_SOURCE_FILE_NM.replace(fileSourcePattern,targetTime)
                    if fileNmPattern:
                        fileInfo.FILE_INFO.FILE_NM = fileInfo.FILE_INFO.FILE_NM.replace(fileNmPattern,targetTime)
                else:
                    if fileSourcePattern:
                        targetTime = self.getTargetTime_v2(fileSourcePattern)
                        fileTargetTime = targetTime
                        fileInfo.FILE_INFO.DATA_SOURCE_FILE_NM = fileInfo.FILE_INFO.DATA_SOURCE_FILE_NM.replace(fileSourcePattern,targetTime)
                    if fileNmPattern:
                        targetTime = self.getTargetTime_v2(fileNmPattern)
                        fileTargetTime = targetTime
                        fileInfo.FILE_INFO.FILE_NM = fileInfo.FILE_INFO.FILE_NM.replace(fileNmPattern,targetTime)
        
        sourceDirTimePattern = self.getTimePattern(interfaceInfo.FTP_SERVER_INFO.DATA_SOURCE_DIR)
        if sourceDirTimePattern:
            # enter when it is not retry
            if files is None:
                targetTime = self.getTargetTime_v2(sourceDirTimePattern)
                interfaceInfo.FTP_SERVER_INFO.DATA_SOURCE_DIR = interfaceInfo.FTP_SERVER_INFO.DATA_SOURCE_DIR.replace(sourceDirTimePattern,targetTime)
            else:
                interfaceInfo.FTP_SERVER_INFO.DATA_SOURCE_DIR = interfaceInfo.FTP_SERVER_INFO.DATA_SOURCE_DIR.replace(sourceDirTimePattern,targetTime)
        print(f"interfaceInfo : {interfaceInfo}")
        return fileTargetTime

    # Oracle
    def getTimeValue(self, timePattern, timeValue, operatorStr):
        #list = [1y, 1M, 1d, 10m]
        timeValue = datetime.strptime(timeValue, "%Y%m%d%H%M")

        operator_mapping = {
            "+": operator.add,
            "-": operator.sub
        }

        operator_func = None

        if operatorStr == '+':
            operator_func = operator_mapping['+']
        else:
            operator_func = operator_mapping['-']

        for value in timePattern:
            print("value ", value)

            numList = self.re.findall(r'\d+', value)
            num = int(numList[0])

            charList = self.re.findall(r'[a-zA-Z]', value)
            char = charList[0]

            if char in "y":
                timeValue = operator_func(timeValue, relativedelta(years=num))
            elif char in "M":
                timeValue = operator_func(timeValue, relativedelta(months=num))
            elif char in "d":
                timeValue = operator_func(timeValue, timedelta(days=num))
            elif char in "H":
                timeValue = operator_func(timeValue, timedelta(hours=num))
            elif char in "m":
                timeValue = operator_func(timeValue, timedelta(minutes=num))

        result_time = timeValue.strftime('%Y%m%d%H%M')

        return result_time

    # Oracle       
    def getRerunTimeVlaue(self, timeParam, tagetTime):
        #list = [1y, 1M, 1d, 10m]
        tagetTime = datetime.strptime(tagetTime, "%Y%m%d%H%M")

        #get pastTime
        for value in timeParam:
            print("value ", value)

            numList = self.re.findall(r'\d+', value)
            num = int(numList[0])

            charList = self.re.findall(r'[a-zA-Z]', value)
            char = charList[0]

            if char in "y":
                tagetTime = tagetTime + relativedelta(years=num) 
            elif char in "M":
                tagetTime = tagetTime + relativedelta(months=num) 
            elif char in "d":
                tagetTime = tagetTime + timedelta(days=num) 
            elif char in "H":
                tagetTime = tagetTime + timedelta(hours=num) 
            elif char in "m":
                tagetTime = tagetTime + timedelta(minutes=num) 

        result_time = tagetTime.strftime('%Y%m%d%H%M')

        return result_time
    

    def getSqlParams(self, data_params):
        #data_params = ["STRING", "10", "${yyyyMMddHH-10M}','${yyyyMMddHH}", "SEF", "${yyyyMMddHH-3M}'] or  ["STRING", "NUM"]
        result_dic = {}
        param_reuslt = []

        current_time = datetime.now() - timedelta(minutes=5) 
        current_time = current_time.strftime('%Y%m%d%H%M')

        # targetTime will be filename .. if data_params has no timePattern, targetTime will be current_time
        targetTime = current_time

        for data_param in data_params:
            if "$" in data_param:
                # data_param = ${yyyyMMddHH-10M}
                if "-" in data_param:
                    matches = self.re.findall(r'\d+\w', data_param)
                    calculated_time = self.getTimeValue(matches, current_time, "-")
                    targetTime = calculated_time
                    param_reuslt.append(calculated_time)
                # data_param = ${yyyyMMddHH}
                else:
                    targetTime = current_time
                    param_reuslt.append(current_time)
            else:
                param_reuslt.append(data_param)
        
        result_dic['param_result'] = param_reuslt
        result_dic['target_time'] = targetTime

        return result_dic

    def getQueryUsingRowNum(data_query, start_row_num, end_row_num):
        # select org.*
        #   from (select rownum as rn, CTIME from PM_LINK_ENB_KPI_1H WHERE EVENT_TIME=to_date('2023072010','yyyymmddhh24')) org
        #   WHERE rn between 3 and 10;

        select_index = data_query.lower().index("select")
        sub_query = "SELECT ROWNUM AS rn" + data_query[select_index + len("select"):]
    
        params = []
        params.append(sub_query)
        params.append(start_row_num)
        params.append(end_row_num)

        sql = "SELECT * FROM ({}) WHERE rn > {} AND rn <= {}"
        formatted_sql = formatted_sql.format(*params)
        
        return formatted_sql
    
    
    def replaceOracleTimeParameters(self, timeParameters):
        #"${yyyyMMdd HHmm-1y1M1d10m},${yyyyMMdd HHmm-30d}"
        timeParamList = timeParameters.split(",")
        returnList = []
        
        #"${yyyyMMdd HHmm-1y1M1d10m}
        for timeParam in timeParamList:
            current_time = datetime.now() - timedelta(minutes=5) 
            current_time = current_time.strftime('%Y%m%d%H%M')

            if "-" in timeParam:
                matches = self.re.findall(r'\d+\w', timeParam)
                returnList.append(self.getTimeValue(matches, current_time, "-"))

            else:
                returnList.append(current_time)

        return returnList
    
    
    # Oracle
    def getRerunTimeParameters(self, timeParameters, tagetTime):
        # tagetTime = 'yyyyMMddHHmm'
        returnList = []

        # case: timeParameters len = 1
        if "," not in timeParameters:
            returnList.append(tagetTime)

        # case: timeParameters len = 2        
        else:
            #timeParameters = "${yyyyMMdd HHmm-1y1M1d10m},${yyyyMMdd HHmm-30d}"
            timeParamList = timeParameters.split(",")
            #"${yyyyMMdd HHmm-1y1M1d10m}
            matches = self.re.findall(r'\d+\w', timeParamList[0])
            pastTargetTime = self.getTimeValue(matches, tagetTime, "+")
            returnList.append(tagetTime)

            #${yyyyMMdd HHmm-30d}"
            if "-" in timeParamList[1]:
                matches = self.re.findall(r'\d+\w', timeParamList[1])
                pastTime = self.getTimeValue(matches, pastTargetTime, "-")
                returnList.append(pastTime)

            #${yyyyMMdd HHmm}
            else:
                returnList.append(pastTargetTime)

        return returnList
    
    def getFilenm(self,filePath):
        filenm = os.path.basename(filePath)

        datePattern = r"\d{6,}"
        filenm = self.re.sub(datePattern,"",filenm)
        extPtn = r"\.\w+$"
        filenm = self.re.sub(extPtn,"",filenm)
        rmUndB = r"^_|_$"
        filenm = self.re.sub(rmUndB,"",filenm)
        return filenm